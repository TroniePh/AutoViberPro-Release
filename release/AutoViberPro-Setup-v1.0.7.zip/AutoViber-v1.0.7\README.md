# Auto Viber Pro

Auto Viber Pro renders scheduled check-in images and sends them to a Viber Desktop group on Windows.

Developed by Pham Duy  
Contact: 0868609901

Important Viber limitation: normal Viber Groups do not support connected bots. This app automates Viber Desktop, so the PC must be logged in and Viber Desktop must be usable.

## Open The App

```powershell
cd "E:\auto viber"
.\scripts\setup.ps1
.\scripts\start_gui.ps1
```

You can also double-click:

```text
start_gui.cmd
```

For customer installation, double-click:

```text
install.cmd
```

The release file is a ZIP package. Extract it first, then run `install.cmd`.

## Main Features

- Compact commercial desktop UI with custom logo
- Login screen with first-login password change
- License activation: Test, Premium, and Lifetime
- Multi-image preview for all configured slots
- Schedule editor for Viber group, image folders, active days, and time slots
- Double-click a slot row to edit it, then use `Lưu slot` and `Lưu`
- Fixed top-right date, coordinate, and location stamp style
- Stamp toggle: ON renders text overlay, OFF sends the original source image file
- Stamp font target: San Francisco SF Pro Text Regular, 14pt equivalent, thin black stroke
- Render keeps original image dimensions and writes lossless PNG output
- Viber Desktop automation with background/tray mode
- Hidden auto-update settings through `config.toml`
- Windows startup install/uninstall

## Image Folders

Default files:

- `images/normal/5pm.png`, `images/normal/6pm.png`, `images/normal/7pm.png`
- `images/friday/5pm.png`, `images/friday/6pm.png`, `images/friday/7pm.png`

Monday, Tuesday, Wednesday, Thursday, Saturday, and Sunday use the normal folder.
Friday uses the Friday folder.

Rendered images are saved to `output`.

## Login And License

Default first-run login:

```text
Username: admin
Password: Admin@123
```

The app requires changing this password after the first login.

After activation, the license plan and app version are shown in the bottom corner.
Login, changed password, and license activation are stored outside the app folder at:

```text
%APPDATA%\AutoViberPro\auth.json
```

Online license checking can be configured in `config.toml`:

```toml
[license]
manifest_url = "https://raw.githubusercontent.com/OWNER/REPO/main/keys.json"
```

Recommended public `keys.json` using SHA-256 key hashes:

```json
{
  "keys": [
    {
      "id": "premium_3m",
      "sha256": "1bd739c726e02121a1718ebafd83ea5be6e2a951ca1baa69c92a563f7e9a1c2a",
      "plan": "Premium",
      "expires_at": "2026-08-23T00:00:00+00:00",
      "active": true
    },
    {
      "id": "test",
      "sha256": "a606022973df086f52e2d7f4879b01c03d8b8fa8312db8cf2c10ea38fd023c76",
      "plan": "Test",
      "expires_at": "2026-05-31T00:00:00+00:00",
      "active": true
    },
    {
      "id": "lifetime",
      "sha256": "2da88469f09f8670f0019e70b1a6a3c756afebf371e81158bdf0cbab8499b905",
      "plan": "Lifetime",
      "expires_at": "",
      "active": true
    }
  ]
}
```

If a key is removed from the online file or set to `active: false`, the app blocks use after the next license check.

## Stamp Font

Place `SF-Pro-Text-Regular.otf` at:

```text
assets\fonts\SF-Pro-Text-Regular.otf
```

If this file is missing, the app falls back to a regular Windows system font.

## Hidden Update Config

Update settings are intentionally hidden from the customer UI. Configure them directly in `config.toml` under `[updates]` when a release channel is ready.

Simple Git/raw-file update mode:

```toml
[updates]
enabled = true
manifest_url = "https://raw.githubusercontent.com/OWNER/REPO/main/version.json"
asset_keyword = "AutoViber"
auto_check_on_start = true
auto_download_install = false
```

Example `version.json`:

```json
{
  "version": "1.0.7",
  "asset_name": "AutoViberPro-Setup-v1.0.7.zip",
  "download_url": "https://github.com/OWNER/REPO/releases/download/v1.0.7/AutoViberPro-Setup-v1.0.7.zip",
  "notes": "Bug fixes and improvements"
}
```

When a newer version is found, the app asks the customer to confirm, then downloads and installs it.

Build a release ZIP:

```powershell
.\scripts\build_release_zip.ps1
```

The generated file is placed in `dist`.

## CLI Fallback

Render one image:

```powershell
.\.venv\Scripts\python.exe .\auto_viber.py render 5pm
```

Send one configured slot immediately:

```powershell
.\.venv\Scripts\python.exe .\auto_viber.py send-now 5pm
```

Run scheduler without GUI:

```powershell
.\.venv\Scripts\python.exe .\auto_viber.py run
```

## Windows Startup

Install:

```powershell
.\scripts\install_startup_task.ps1
```

Remove:

```powershell
.\scripts\uninstall_startup_task.ps1
```
