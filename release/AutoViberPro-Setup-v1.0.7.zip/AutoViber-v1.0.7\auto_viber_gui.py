from __future__ import annotations

import argparse
import json
import queue
import subprocess
import threading
import tkinter as tk
import tomllib
import webbrowser
from datetime import date, datetime
from pathlib import Path
from tkinter import colorchooser, filedialog, messagebox
from typing import Any, Callable

import customtkinter as ctk
from PIL import Image, ImageDraw

import auto_viber as engine
import auth
import updater
from app_version import APP_NAME, APP_VERSION, DEVELOPER_CONTACT, DEVELOPER_DISPLAY


ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config.toml"
ASSETS_DIR = ROOT / "assets"
LOGO_PATH = ASSETS_DIR / "logo.png"
LOGO_ICO_PATH = ASSETS_DIR / "logo.ico"

DEFAULT_FONT_PATH = "assets/fonts/SF-Pro-Text-Regular.otf"
DEFAULT_OVERLAY_BLOCK = {
    "text": "{stamp_datetime}\n{location}",
    "x": "-2.0%",
    "y": "1.0%",
    "font_size": "2.7%",
    "fill": "#F2F2F2",
    "stroke_width": 0,
    "stroke_fill": "#000000",
    "anchor": "ra",
    "align": "right",
    "spacing": 0,
    "shadow_enabled": True,
    "shadow_dx": 2,
    "shadow_dy": 2,
    "shadow_fill": "#000000",
    "shadow_opacity": 110,
}

DAYS = [
    ("monday", "T2"),
    ("tuesday", "T3"),
    ("wednesday", "T4"),
    ("thursday", "T5"),
    ("friday", "T6"),
    ("saturday", "T7"),
    ("sunday", "CN"),
]

COLORS = {
    "bg": "#F3F6FA",
    "card": "#FFFFFF",
    "soft": "#F7F9FC",
    "line": "#D8E0EB",
    "text": "#111827",
    "muted": "#667085",
    "blue": "#2563EB",
    "blue2": "#1D4ED8",
    "green": "#079455",
    "green2": "#067647",
    "red": "#D92D20",
    "red2": "#B42318",
    "slate": "#475467",
    "dark": "#0F172A",
    "purple": "#7C3AED",
    "amber": "#F79009",
}


def read_raw_config(path: Path = CONFIG_PATH) -> dict[str, Any]:
    if not path.exists():
        return {}
    return tomllib.loads(path.read_text(encoding="utf-8"))


def read_license_config(path: Path = CONFIG_PATH) -> dict[str, Any]:
    return dict(read_raw_config(path).get("license", {}))


def quoted(value: Any) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(value)
    if isinstance(value, list):
        return "[" + ", ".join(toml_value(item) for item in value) + "]"
    return quoted(value)


def resolve_user_path(value: str) -> Path:
    path = Path(value.strip()).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    return path


def normalize_config_path(value: str, allow_relative: bool = True) -> str:
    text = value.strip()
    if not text:
        return ""
    path = Path(text).expanduser()
    if allow_relative and path.is_absolute():
        try:
            return path.resolve().relative_to(ROOT).as_posix()
        except ValueError:
            pass
    return str(path).replace("\\", "/")


def int_from(value: str, field: str) -> int:
    try:
        return int(str(value).strip())
    except ValueError as exc:
        raise engine.ConfigError(f"{field} phải là số nguyên.") from exc


def float_from(value: str, field: str) -> float:
    try:
        return float(str(value).strip())
    except ValueError as exc:
        raise engine.ConfigError(f"{field} phải là số.") from exc


def write_config(path: Path, data: dict[str, Any]) -> None:
    lines: list[str] = []
    lines.append(f"group_name = {toml_value(data['group_name'])}")
    lines.append(f"address = {toml_value(data['address'])}")
    lines.append("")

    lines.append("[stamp]")
    lines.append(f"datetime_format = {toml_value(data['stamp']['datetime_format'])}")
    lines.append(f"latitude = {toml_value(data['stamp']['latitude'])}")
    lines.append(f"longitude = {toml_value(data['stamp']['longitude'])}")
    lines.append(f"location_lines = {toml_value(data['stamp']['location_lines'])}")
    lines.append("")

    lines.append("[folders]")
    lines.append(f"normal = {toml_value(data['folders']['normal'])}")
    lines.append(f"friday = {toml_value(data['folders']['friday'])}")
    lines.append(f"output = {toml_value(data['folders']['output'])}")
    lines.append("")

    lines.append("[schedule]")
    lines.append(f"active_days = {toml_value(data['schedule']['active_days'])}")
    lines.append(f"date_format = {toml_value(data['schedule']['date_format'])}")
    lines.append(f"late_window_minutes = {toml_value(data['schedule']['late_window_minutes'])}")
    lines.append("")
    for slot in data["schedule"]["slots"]:
        lines.append("[[schedule.slots]]")
        lines.append(f"name = {toml_value(slot['name'])}")
        lines.append(f"time = {toml_value(slot['time'])}")
        lines.append(f"image = {toml_value(slot['image'])}")
        lines.append(f"label = {toml_value(slot['label'])}")
        lines.append("")

    lines.append("[overlay]")
    lines.append(f"enabled = {toml_value(data['overlay']['enabled'])}")
    lines.append(f"font_path = {toml_value(data['overlay']['font_path'])}")
    lines.append("")
    for block in data["overlay"]["blocks"]:
        lines.append("[[overlay.blocks]]")
        for key in [
            "text",
            "x",
            "y",
            "font_size",
            "fill",
            "stroke_width",
            "stroke_fill",
            "anchor",
            "align",
            "spacing",
            "shadow_enabled",
            "shadow_dx",
            "shadow_dy",
            "shadow_fill",
            "shadow_opacity",
        ]:
            if key in block and block[key] != "":
                lines.append(f"{key} = {toml_value(block[key])}")
        lines.append("")

    lines.append("[viber]")
    for key in [
        "exe_path",
        "search_hotkey",
        "search_wait_seconds",
        "search_enter_count",
        "press_enter_to_send",
        "send_original_as_file",
        "preview_wait_seconds",
        "wait_seconds",
        "pause_seconds",
    ]:
        lines.append(f"{key} = {toml_value(data['viber'][key])}")
    lines.append("")

    lines.append("[updates]")
    for key in [
        "enabled",
        "repo",
        "release_api_url",
        "manifest_url",
        "asset_keyword",
        "auto_check_on_start",
        "auto_download_install",
    ]:
        lines.append(f"{key} = {toml_value(data['updates'][key])}")
    lines.append("")

    lines.append("[license]")
    lines.append(f"manifest_url = {toml_value(data['license'].get('manifest_url', ''))}")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


class LoginWindow(ctk.CTk):
    def __init__(self) -> None:
        ctk.set_appearance_mode("Light")
        ctk.set_default_color_theme("blue")
        super().__init__()

        self.authenticated = False
        self.session: auth.AuthSession | None = None
        self.title(f"{APP_NAME} Login")
        self.geometry("430x420")
        self.resizable(False, False)
        self.configure(fg_color=COLORS["bg"])
        if LOGO_PATH.exists():
            self.window_icon = tk.PhotoImage(file=str(LOGO_PATH))
            self.iconphoto(False, self.window_icon)
        else:
            self.window_icon = None

        self.card = ctk.CTkFrame(self, fg_color=COLORS["card"], border_width=1, border_color=COLORS["line"], corner_radius=14)
        self.card.pack(fill="both", expand=True, padx=22, pady=22)
        self._build_login()

    def _clear(self) -> None:
        for child in self.card.winfo_children():
            child.destroy()

    def _title(self, title: str, subtitle: str) -> None:
        if LOGO_PATH.exists():
            logo = Image.open(LOGO_PATH).convert("RGBA")
            self.login_logo = ctk.CTkImage(light_image=logo, dark_image=logo, size=(54, 54))
            ctk.CTkLabel(self.card, text="", image=self.login_logo).pack(pady=(22, 8))
        ctk.CTkLabel(self.card, text=title, text_color=COLORS["text"], font=("Segoe UI", 20, "bold")).pack()
        ctk.CTkLabel(self.card, text=subtitle, text_color=COLORS["muted"], font=("Segoe UI", 11)).pack(pady=(4, 18))

    def _entry(self, label: str, show: str = "") -> ctk.CTkEntry:
        ctk.CTkLabel(self.card, text=label, text_color=COLORS["muted"], font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x", padx=30, pady=(0, 4))
        entry = ctk.CTkEntry(self.card, height=34, show=show, border_width=1, border_color=COLORS["line"], fg_color="#FFFFFF", corner_radius=8)
        entry.pack(fill="x", padx=30, pady=(0, 12))
        return entry

    def _build_login(self) -> None:
        self._clear()
        self._title(APP_NAME, "Đăng nhập để sử dụng phần mềm")
        self.username_entry = self._entry("Tài khoản")
        self.password_entry = self._entry("Mật khẩu", show="*")
        self.username_entry.insert(0, auth.DEFAULT_USERNAME)
        self._btn(self.card, "Đăng nhập", self._login, width=150, height=36).pack(pady=(4, 12))
        self.password_entry.bind("<Return>", lambda _event: self._login())

    def _login(self) -> None:
        try:
            self.session = auth.verify_login(self.username_entry.get(), self.password_entry.get())
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        if self.session.must_change_password:
            self._build_change_password()
            return
        self._after_login()

    def _build_change_password(self) -> None:
        self._clear()
        self._title("Đổi mật khẩu", "Lần đăng nhập đầu tiên cần đổi mật khẩu")
        self.new_password_entry = self._entry("Mật khẩu mới", show="*")
        self.confirm_password_entry = self._entry("Nhập lại mật khẩu", show="*")
        self._btn(self.card, "Lưu mật khẩu", self._change_password, width=150, height=36).pack(pady=(4, 12))
        self.confirm_password_entry.bind("<Return>", lambda _event: self._change_password())

    def _change_password(self) -> None:
        if not self.session:
            self._build_login()
            return
        password = self.new_password_entry.get()
        if password != self.confirm_password_entry.get():
            messagebox.showerror(APP_NAME, "Mật khẩu nhập lại không khớp.")
            return
        try:
            auth.change_password(self.session.username, password)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self._after_login()

    def _after_login(self) -> None:
        status = auth.license_status(read_license_config())
        if not status.active:
            self._build_activate(status.reason)
            return
        self.authenticated = True
        self.destroy()

    def _build_activate(self, reason: str = "") -> None:
        self._clear()
        self._title("Kích hoạt license", reason or "Nhập license key để mở phần mềm")
        self.license_entry = self._entry("License key")
        self._btn(self.card, "Kích hoạt", self._activate, width=150, height=36).pack(pady=(4, 12))
        self.license_entry.bind("<Return>", lambda _event: self._activate())

    def _activate(self) -> None:
        try:
            status = auth.activate_license(self.license_entry.get(), read_license_config())
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        messagebox.showinfo(APP_NAME, f"Đã kích hoạt: {status.display_name}")
        self.authenticated = True
        self.destroy()

    def _btn(
        self,
        parent: ctk.CTkFrame,
        text: str,
        command: Callable[..., Any],
        width: int = 90,
        height: int = 34,
    ) -> ctk.CTkButton:
        return ctk.CTkButton(parent, text=text, command=command, fg_color=COLORS["blue"], hover_color=COLORS["blue2"], width=width, height=height, corner_radius=8, font=("Segoe UI", 11, "bold"))


class AutoViberCompact(ctk.CTk):
    def __init__(self) -> None:
        ctk.set_appearance_mode("Light")
        ctk.set_default_color_theme("blue")
        super().__init__()

        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1020x720")
        self.minsize(940, 650)
        self.configure(fg_color=COLORS["bg"])
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        if LOGO_PATH.exists():
            self.window_icon = tk.PhotoImage(file=str(LOGO_PATH))
            self.iconphoto(False, self.window_icon)

        self.slots: list[dict[str, str]] = []
        self.selected_slot_index: int | None = None
        self.latest_release: updater.ReleaseInfo | None = None
        self.license_config = read_license_config()
        self.license_status = auth.license_status(self.license_config)
        self.license_warning_shown = False
        self.current_preview_path: Path | None = None
        self.preview_image: ctk.CTkImage | None = None
        self.preview_images: list[ctk.CTkImage] = []
        self.logo_image: ctk.CTkImage | None = None
        self.window_icon: tk.PhotoImage | None = None
        self.tray_icon: Any | None = None
        self.tray_thread: threading.Thread | None = None

        self.log_queue: queue.Queue[str] = queue.Queue()
        self.scheduler_stop = threading.Event()
        self.scheduler_thread: threading.Thread | None = None

        self._build()
        self._load_config()
        self._refresh_slots()
        self._refresh_status()
        self.after(200, self._flush_logs)
        self.after(30_000, self._tick)
        self.after(1500, self._startup_update_check)

    def _build(self) -> None:
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        header = ctk.CTkFrame(self, fg_color=COLORS["card"], corner_radius=0, height=72)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)
        header.grid_propagate(False)

        if LOGO_PATH.exists():
            logo = Image.open(LOGO_PATH).convert("RGBA")
            self.logo_image = ctk.CTkImage(light_image=logo, dark_image=logo, size=(46, 46))
            ctk.CTkLabel(header, text="", image=self.logo_image, width=46, height=46).grid(row=0, column=0, padx=(18, 10), pady=13)
        else:
            ctk.CTkLabel(
                header,
                text="AV",
                width=42,
                height=42,
                corner_radius=12,
                fg_color=COLORS["blue"],
                text_color="#FFFFFF",
                font=("Segoe UI", 16, "bold"),
            ).grid(row=0, column=0, padx=(18, 10), pady=15)
        title = ctk.CTkFrame(header, fg_color="transparent")
        title.grid(row=0, column=1, sticky="w")
        ctk.CTkLabel(title, text=APP_NAME, text_color=COLORS["text"], font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ctk.CTkLabel(
            title,
            text=f"v{APP_VERSION}  |  Developed by {DEVELOPER_DISPLAY}  |  {DEVELOPER_CONTACT}",
            text_color=COLORS["muted"],
            font=("Segoe UI", 11),
        ).pack(anchor="w")

        self.status_pill = ctk.CTkLabel(
            header,
            text="Đang dừng",
            width=96,
            height=30,
            corner_radius=15,
            fg_color="#EEF2F6",
            text_color=COLORS["slate"],
            font=("Segoe UI", 12, "bold"),
        )
        self.status_pill.grid(row=0, column=2, padx=(0, 10))
        self._btn(header, "Lưu", self.save_config, width=72).grid(row=0, column=3, padx=4)
        self._btn(header, "Chạy", self.start_scheduler, color=COLORS["green"], hover=COLORS["green2"], width=72).grid(row=0, column=4, padx=4)
        self._btn(header, "Dừng", self.stop_scheduler, color=COLORS["red"], hover=COLORS["red2"], width=72).grid(row=0, column=5, padx=(4, 18))

        self.nav = ctk.CTkSegmentedButton(
            self,
            values=["Tổng quan", "Cấu hình", "Vị trí", "Viber", "Logs"],
            height=36,
            command=self._switch_tab,
        )
        self.nav.grid(row=1, column=0, sticky="ew", padx=18, pady=(14, 10))
        self.nav.set("Tổng quan")

        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.grid(row=2, column=0, sticky="nsew", padx=18, pady=(0, 6))
        self.body.grid_columnconfigure(0, weight=1)
        self.body.grid_rowconfigure(0, weight=1)

        self.pages: dict[str, ctk.CTkFrame] = {}
        for key in ["Tổng quan", "Cấu hình", "Vị trí", "Viber", "Logs"]:
            frame = ctk.CTkFrame(self.body, fg_color="transparent")
            frame.grid(row=0, column=0, sticky="nsew")
            frame.grid_remove()
            self.pages[key] = frame

        self._build_main_page(self.pages["Tổng quan"])
        self._build_config_page(self.pages["Cấu hình"])
        self._build_stamp_page(self.pages["Vị trí"])
        self._build_viber_page(self.pages["Viber"])
        self._build_logs_page(self.pages["Logs"])
        self.pages["Tổng quan"].grid()

        footer = ctk.CTkFrame(self, fg_color="transparent", height=24)
        footer.grid(row=3, column=0, sticky="ew", padx=18, pady=(0, 8))
        footer.grid_columnconfigure(0, weight=1)
        self.license_footer = ctk.CTkLabel(
            footer,
            text=self._license_footer_text(),
            text_color=COLORS["muted"],
            font=("Segoe UI", 10, "bold"),
            anchor="e",
        )
        self.license_footer.grid(row=0, column=0, sticky="e")

    def _build_main_page(self, page: ctk.CTkFrame) -> None:
        page.grid_columnconfigure(0, weight=7)
        page.grid_columnconfigure(1, weight=5)
        page.grid_rowconfigure(1, weight=1)

        left = self._card(page, "Vận hành")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8), pady=(0, 10))
        left.grid_columnconfigure((0, 1, 2), weight=1)

        self.group_summary = self._metric(left, "Nhóm Viber", "-")
        self.slot_summary = self._metric(left, "Khung giờ", "0 slot")
        self.next_summary = self._metric(left, "Slot tiếp theo", "-")
        self.group_summary.grid(row=1, column=0, sticky="ew", padx=(14, 7), pady=(0, 14))
        self.slot_summary.grid(row=1, column=1, sticky="ew", padx=7, pady=(0, 14))
        self.next_summary.grid(row=1, column=2, sticky="ew", padx=(7, 14), pady=(0, 14))

        actions = ctk.CTkFrame(left, fg_color=COLORS["soft"], corner_radius=12)
        actions.grid(row=2, column=0, columnspan=3, sticky="ew", padx=14, pady=(0, 14))
        actions.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)
        self._btn(actions, "Preview tất cả", self.render_preview, height=38).grid(row=0, column=0, sticky="ew", padx=(12, 5), pady=12)
        self._btn(actions, "Gửi thử Viber", self.send_test_selected, color=COLORS["slate"], hover="#344054", height=38).grid(row=0, column=1, sticky="ew", padx=6, pady=12)
        self._btn(actions, "Mở ảnh", self.open_selected_source_image, color=COLORS["slate"], hover="#344054", height=38).grid(row=0, column=2, sticky="ew", padx=6, pady=12)
        self._btn(actions, "Ẩn khay", self.hide_to_tray, color=COLORS["purple"], hover="#6D28D9", height=38).grid(row=0, column=3, sticky="ew", padx=6, pady=12)
        self._btn(actions, "Mở output", lambda: self.open_path(self.output_var.get()), color=COLORS["slate"], hover="#344054", height=38).grid(row=0, column=4, sticky="ew", padx=(5, 12), pady=12)

        schedule = self._card(page, "Lịch gửi")
        schedule.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        schedule.grid_columnconfigure(0, weight=1)
        schedule.grid_rowconfigure(1, weight=1)
        self.main_slots_frame = ctk.CTkFrame(schedule, fg_color="#FFFFFF", corner_radius=10)
        self.main_slots_frame.grid(row=1, column=0, sticky="nsew", padx=14, pady=(0, 14))
        self.main_slots_frame.grid_columnconfigure(0, weight=1)

        right = self._card(page, "Preview")
        right.grid(row=0, column=1, rowspan=2, sticky="nsew", padx=(8, 0))
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(2, weight=1)

        top = ctk.CTkFrame(right, fg_color="transparent")
        top.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 10))
        top.grid_columnconfigure(0, weight=1)
        self.preview_slot_var = tk.StringVar()
        self.preview_date_var = tk.StringVar(value=date.today().isoformat())
        self.preview_slot_combo = ctk.CTkComboBox(top, values=[], variable=self.preview_slot_var, height=34)
        self.preview_slot_combo.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ctk.CTkEntry(top, textvariable=self.preview_date_var, width=120, height=34).grid(row=0, column=1)

        self.preview_gallery = ctk.CTkScrollableFrame(
            right,
            fg_color=COLORS["dark"],
            corner_radius=12,
            scrollbar_button_color="#344054",
            scrollbar_button_hover_color="#475467",
        )
        self.preview_gallery.grid(row=2, column=0, sticky="nsew", padx=14, pady=(0, 10))
        self.preview_gallery.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            self.preview_gallery,
            text="Chưa có preview",
            text_color="#D0D5DD",
            font=("Segoe UI", 13, "bold"),
        ).grid(row=0, column=0, sticky="nsew", padx=16, pady=22)
        self.preview_path_label = ctk.CTkLabel(right, text="", text_color=COLORS["muted"], font=("Segoe UI", 10), anchor="w")
        self.preview_path_label.grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 14))

    def _build_config_page(self, page: ctk.CTkFrame) -> None:
        page.grid_columnconfigure(0, weight=1)
        page.grid_columnconfigure(1, weight=1)
        page.grid_rowconfigure(0, weight=1)

        left = self._card(page, "Thông tin & thư mục")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        left.grid_columnconfigure(0, weight=1)

        self.group_var = tk.StringVar()
        self.address_var = tk.StringVar()
        self.normal_var = tk.StringVar()
        self.friday_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.date_format_var = tk.StringVar()
        self.late_window_var = tk.StringVar()
        self.background_var = tk.BooleanVar(value=True)

        self._field(left, "Tên nhóm Viber", self.group_var).grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 8))
        self._field(left, "Address mặc định", self.address_var).grid(row=2, column=0, sticky="ew", padx=14, pady=(0, 8))
        self._path_field(left, "Ảnh ngày thường", self.normal_var, True).grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 7))
        self._path_field(left, "Ảnh thứ 6", self.friday_var, True).grid(row=4, column=0, sticky="ew", padx=14, pady=(0, 7))
        self._path_field(left, "Output", self.output_var, True).grid(row=5, column=0, sticky="ew", padx=14, pady=(0, 7))

        row = ctk.CTkFrame(left, fg_color="transparent")
        row.grid(row=6, column=0, sticky="ew", padx=14, pady=(0, 7))
        row.grid_columnconfigure((0, 1), weight=1)
        self._field(row, "Định dạng ngày", self.date_format_var).grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self._field(row, "Trễ tối đa phút", self.late_window_var).grid(row=0, column=1, sticky="ew", padx=(6, 0))

        day_box = ctk.CTkFrame(left, fg_color=COLORS["soft"], corner_radius=10)
        day_box.grid(row=7, column=0, sticky="ew", padx=14, pady=(0, 10))
        ctk.CTkLabel(day_box, text="Ngày hoạt động", font=("Segoe UI", 11, "bold"), text_color=COLORS["text"]).grid(row=0, column=0, sticky="w", padx=12, pady=(8, 3), columnspan=7)
        self.day_vars: dict[str, tk.BooleanVar] = {}
        for idx, (day_name, label) in enumerate(DAYS):
            var = tk.BooleanVar(value=day_name != "sunday")
            self.day_vars[day_name] = var
            ctk.CTkCheckBox(day_box, text=label, variable=var, width=39, checkbox_width=17, checkbox_height=17).grid(row=1, column=idx, padx=(8 if idx == 0 else 1, 1), pady=(0, 8))

        right = self._card(page, "Khung giờ")
        right.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(1, weight=1)
        self.config_slots_frame = ctk.CTkFrame(right, fg_color="#FFFFFF", corner_radius=10)
        self.config_slots_frame.grid(row=1, column=0, sticky="nsew", padx=14, pady=(0, 10))
        self.config_slots_frame.grid_columnconfigure(0, weight=1)

        editor = ctk.CTkFrame(right, fg_color=COLORS["soft"], corner_radius=10)
        editor.grid(row=2, column=0, sticky="ew", padx=14, pady=(0, 14))
        editor.grid_columnconfigure((0, 1, 2, 3), weight=1)
        self.slot_name_var = tk.StringVar()
        self.slot_time_var = tk.StringVar()
        self.slot_image_var = tk.StringVar()
        self.slot_label_var = tk.StringVar()
        self._field(editor, "Tên", self.slot_name_var).grid(row=0, column=0, sticky="ew", padx=(10, 5), pady=(10, 8))
        self._field(editor, "Giờ", self.slot_time_var).grid(row=0, column=1, sticky="ew", padx=5, pady=(10, 8))
        self._field(editor, "File ảnh", self.slot_image_var).grid(row=0, column=2, sticky="ew", padx=5, pady=(10, 8))
        self._field(editor, "Check in", self.slot_label_var).grid(row=0, column=3, sticky="ew", padx=(5, 10), pady=(10, 8))
        buttons = ctk.CTkFrame(editor, fg_color="transparent")
        buttons.grid(row=1, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 10))
        self._btn(buttons, "Thêm", self.add_slot, width=78).pack(side="left", padx=(0, 6))
        self._btn(buttons, "Lưu slot", self.update_slot, color=COLORS["slate"], hover="#344054", width=82).pack(side="left", padx=6)
        self._btn(buttons, "Xóa", self.remove_slot, color=COLORS["red"], hover=COLORS["red2"], width=72).pack(side="left", padx=6)

    def _build_stamp_page(self, page: ctk.CTkFrame) -> None:
        page.grid_columnconfigure(0, weight=1)
        page.grid_columnconfigure(1, weight=1)
        page.grid_rowconfigure(0, weight=1)

        left = self._card(page, "Address / Location")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        left.grid_columnconfigure(0, weight=1)
        self.stamp_datetime_var = tk.StringVar()
        self.latitude_var = tk.StringVar()
        self.longitude_var = tk.StringVar()
        self.location_text = ctk.CTkTextbox(left, height=108, corner_radius=8, border_width=1, border_color=COLORS["line"], fg_color="#FFFFFF")
        self._field(left, "Định dạng ngày giờ", self.stamp_datetime_var).grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 10))
        row = ctk.CTkFrame(left, fg_color="transparent")
        row.grid(row=2, column=0, sticky="ew", padx=14, pady=(0, 10))
        row.grid_columnconfigure((0, 1), weight=1)
        self._field(row, "Latitude", self.latitude_var).grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self._field(row, "Longitude", self.longitude_var).grid(row=0, column=1, sticky="ew", padx=(6, 0))
        ctk.CTkLabel(left, text="Location lines", text_color=COLORS["muted"], font=("Segoe UI", 11, "bold")).grid(row=3, column=0, sticky="w", padx=14, pady=(0, 5))
        self.location_text.grid(row=4, column=0, sticky="ew", padx=14, pady=(0, 10))
        self._btn(left, "Khôi phục mẫu mặc định", self.apply_stamp_preset, width=178).grid(row=5, column=0, sticky="w", padx=14, pady=(0, 14))

        right = self._card(page, "Mẫu chữ mặc định")
        right.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(1, weight=1)
        self.font_path_var = tk.StringVar()
        self.overlay_text_var = tk.StringVar()
        self.overlay_enabled_var = tk.BooleanVar(value=True)
        self.overlay_x_var = tk.StringVar()
        self.overlay_y_var = tk.StringVar()
        self.overlay_size_var = tk.StringVar()
        self.overlay_fill_var = tk.StringVar()
        self.overlay_stroke_width_var = tk.StringVar()
        self.overlay_stroke_fill_var = tk.StringVar()
        self.overlay_anchor_var = tk.StringVar()
        self.overlay_align_var = tk.StringVar()
        self.overlay_spacing_var = tk.StringVar()
        self.overlay_shadow_enabled_var = tk.BooleanVar(value=True)
        self.overlay_shadow_dx_var = tk.StringVar()
        self.overlay_shadow_dy_var = tk.StringVar()
        self.overlay_shadow_fill_var = tk.StringVar()
        self.overlay_shadow_opacity_var = tk.StringVar()
        self._set_default_overlay_vars()

        controls = ctk.CTkFrame(right, fg_color=COLORS["soft"], corner_radius=12)
        controls.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 12))
        controls.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkSwitch(controls, text="Thêm chữ lên ảnh", variable=self.overlay_enabled_var).grid(row=0, column=0, columnspan=3, sticky="w", padx=12, pady=(10, 8))
        self._field(controls, "X", self.overlay_x_var).grid(row=1, column=0, sticky="ew", padx=(12, 5), pady=(0, 8))
        self._field(controls, "Y", self.overlay_y_var).grid(row=1, column=1, sticky="ew", padx=5, pady=(0, 8))
        self._field(controls, "Size", self.overlay_size_var).grid(row=1, column=2, sticky="ew", padx=(5, 12), pady=(0, 8))
        self._field(controls, "Màu chữ", self.overlay_fill_var).grid(row=2, column=0, sticky="ew", padx=(12, 5), pady=(0, 8))
        self._field(controls, "Vien", self.overlay_stroke_width_var).grid(row=2, column=1, sticky="ew", padx=5, pady=(0, 8))
        self._field(controls, "Màu viền", self.overlay_stroke_fill_var).grid(row=2, column=2, sticky="ew", padx=(5, 12), pady=(0, 8))
        self._field(controls, "Spacing", self.overlay_spacing_var).grid(row=3, column=0, sticky="ew", padx=(12, 5), pady=(0, 10))
        ctk.CTkSwitch(controls, text="Drop shadow", variable=self.overlay_shadow_enabled_var).grid(row=4, column=0, sticky="w", padx=(12, 5), pady=(0, 8))
        self._field(controls, "Shadow X", self.overlay_shadow_dx_var).grid(row=4, column=1, sticky="ew", padx=5, pady=(0, 8))
        self._field(controls, "Shadow Y", self.overlay_shadow_dy_var).grid(row=4, column=2, sticky="ew", padx=(5, 12), pady=(0, 8))
        self._field(controls, "Shadow màu", self.overlay_shadow_fill_var).grid(row=5, column=0, sticky="ew", padx=(12, 5), pady=(0, 10))
        self._field(controls, "Shadow opacity", self.overlay_shadow_opacity_var).grid(row=5, column=1, sticky="ew", padx=5, pady=(0, 10))
        buttons = ctk.CTkFrame(controls, fg_color="transparent")
        buttons.grid(row=5, column=2, sticky="e", padx=(5, 12), pady=(0, 10))
        self._btn(buttons, "Màu chữ", lambda: self.choose_color(self.overlay_fill_var), width=74, height=30).pack(side="left", padx=(0, 6))
        self._btn(buttons, "Màu viền", lambda: self.choose_color(self.overlay_stroke_fill_var), color=COLORS["slate"], hover="#344054", width=78, height=30).pack(side="left", padx=6)
        self._btn(buttons, "Đặt lại", self._set_default_overlay_vars, color=COLORS["red"], hover=COLORS["red2"], width=68, height=30).pack(side="left", padx=(6, 0))

        sample = ctk.CTkFrame(right, fg_color="#1F2937", corner_radius=12)
        sample.grid(row=2, column=0, sticky="nsew", padx=14, pady=(0, 14))
        sample.grid_columnconfigure(0, weight=1)
        sample.grid_rowconfigure(0, weight=1)
        ctk.CTkLabel(
            sample,
            text="May 23, 2026 at 7:39:40 PM\nNational Road 1\nKhanh Hoa\nDien Lac\nVietnam",
            text_color="#FFFFFF",
            font=("Segoe UI", 14),
            justify="right",
            anchor="ne",
        ).grid(row=0, column=0, sticky="ne", padx=18, pady=18)

    def _build_viber_page(self, page: ctk.CTkFrame) -> None:
        page.grid_columnconfigure(0, weight=1)
        page.grid_columnconfigure(1, weight=1)

        left = self._card(page, "Viber Desktop")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        left.grid_columnconfigure(0, weight=1)
        self.viber_exe_var = tk.StringVar()
        self.search_hotkey_var = tk.StringVar()
        self.search_wait_var = tk.StringVar()
        self.search_enter_var = tk.StringVar()
        self.preview_wait_var = tk.StringVar()
        self.wait_seconds_var = tk.StringVar()
        self.pause_seconds_var = tk.StringVar()
        self.press_enter_var = tk.BooleanVar(value=True)
        self.send_original_as_file_var = tk.BooleanVar(value=True)
        self._path_field(left, "Viber.exe", self.viber_exe_var, False).grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 10))
        row = ctk.CTkFrame(left, fg_color="transparent")
        row.grid(row=2, column=0, sticky="ew", padx=14, pady=(0, 10))
        row.grid_columnconfigure((0, 1, 2), weight=1)
        self._field(row, "Search hotkey", self.search_hotkey_var).grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self._field(row, "Search wait", self.search_wait_var).grid(row=0, column=1, sticky="ew", padx=5)
        self._field(row, "Enter count", self.search_enter_var).grid(row=0, column=2, sticky="ew", padx=(5, 0))
        row2 = ctk.CTkFrame(left, fg_color="transparent")
        row2.grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 10))
        row2.grid_columnconfigure((0, 1, 2), weight=1)
        self._field(row2, "Preview wait", self.preview_wait_var).grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self._field(row2, "Open wait", self.wait_seconds_var).grid(row=0, column=1, sticky="ew", padx=5)
        self._field(row2, "Pause", self.pause_seconds_var).grid(row=0, column=2, sticky="ew", padx=(5, 0))
        ctk.CTkSwitch(left, text="Nhấn Enter để gửi sau khi paste ảnh", variable=self.press_enter_var).grid(row=4, column=0, sticky="w", padx=14, pady=(0, 10))
        ctk.CTkSwitch(left, text="Tắt chữ thì gửi file gốc", variable=self.send_original_as_file_var).grid(row=5, column=0, sticky="w", padx=14, pady=(0, 10))
        ctk.CTkSwitch(left, text="Chạy ngầm khi đóng cửa sổ", variable=self.background_var).grid(row=6, column=0, sticky="w", padx=14, pady=(0, 10))
        buttons = ctk.CTkFrame(left, fg_color=COLORS["soft"], corner_radius=10)
        buttons.grid(row=7, column=0, sticky="ew", padx=14, pady=(0, 14))
        self._btn(buttons, "Cài startup", self.install_startup, width=110).pack(side="left", padx=12, pady=12)
        self._btn(buttons, "Gỡ startup", self.uninstall_startup, color=COLORS["red"], hover=COLORS["red2"], width=110).pack(side="left", padx=6, pady=12)

        right = self._card(page, "Thông tin phần mềm")
        right.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        right.grid_columnconfigure(0, weight=1)
        self.update_enabled_var = tk.BooleanVar(value=True)
        self.update_auto_check_var = tk.BooleanVar(value=True)
        self.update_auto_install_var = tk.BooleanVar(value=False)
        self.update_repo_var = tk.StringVar()
        self.update_api_url_var = tk.StringVar()
        self.update_manifest_url_var = tk.StringVar()
        self.update_keyword_var = tk.StringVar()
        self.update_status_label = ctk.CTkLabel(right, text=f"Auto Viber Pro v{APP_VERSION}", text_color=COLORS["text"], font=("Segoe UI", 16, "bold"), anchor="w")
        self.update_status_label.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 6))
        ctk.CTkLabel(
            right,
            text=f"Developed by {DEVELOPER_DISPLAY}\nContact: {DEVELOPER_CONTACT}",
            text_color=COLORS["muted"],
            font=("Segoe UI", 12),
            justify="left",
            anchor="w",
        ).grid(row=2, column=0, sticky="ew", padx=14, pady=(0, 14))

    def _build_logs_page(self, page: ctk.CTkFrame) -> None:
        page.grid_columnconfigure(0, weight=1)
        page.grid_rowconfigure(0, weight=1)
        card = self._card(page, "Nhật ký hệ thống")
        card.grid(row=0, column=0, sticky="nsew")
        card.grid_columnconfigure(0, weight=1)
        card.grid_rowconfigure(1, weight=1)
        self.log_text = ctk.CTkTextbox(card, fg_color=COLORS["dark"], text_color="#E5E7EB", font=("Consolas", 11), corner_radius=10)
        self.log_text.grid(row=1, column=0, sticky="nsew", padx=14, pady=(0, 10))
        self._btn(card, "Xóa log", lambda: self.log_text.delete("1.0", "end"), color=COLORS["slate"], hover="#344054", width=80).grid(row=2, column=0, sticky="e", padx=14, pady=(0, 14))

    def _card(self, parent: ctk.CTkFrame, title: str) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(parent, fg_color=COLORS["card"], border_width=1, border_color=COLORS["line"], corner_radius=14)
        ctk.CTkLabel(frame, text=title, text_color=COLORS["text"], font=("Segoe UI", 14, "bold"), anchor="w").grid(row=0, column=0, sticky="w", padx=14, pady=(13, 12), columnspan=10)
        return frame

    def _metric(self, parent: ctk.CTkFrame, label: str, value: str) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(parent, fg_color=COLORS["soft"], corner_radius=12)
        ctk.CTkLabel(frame, text=label, text_color=COLORS["muted"], font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
        value_label = ctk.CTkLabel(frame, text=value, text_color=COLORS["text"], font=("Segoe UI", 17, "bold"))
        value_label.pack(anchor="w", padx=12, pady=(0, 10))
        frame.value_label = value_label  # type: ignore[attr-defined]
        return frame

    def _field(self, parent: ctk.CTkFrame, label: str, variable: tk.StringVar) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(frame, text=label, text_color=COLORS["muted"], font=("Segoe UI", 10, "bold"), anchor="w").grid(row=0, column=0, sticky="w", pady=(0, 3))
        ctk.CTkEntry(frame, textvariable=variable, height=30, border_width=1, border_color=COLORS["line"], fg_color="#FFFFFF", corner_radius=8).grid(row=1, column=0, sticky="ew")
        return frame

    def _path_field(self, parent: ctk.CTkFrame, label: str, variable: tk.StringVar, folder: bool) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(frame, text=label, text_color=COLORS["muted"], font=("Segoe UI", 10, "bold"), anchor="w").grid(row=0, column=0, sticky="w", columnspan=3, pady=(0, 3))
        ctk.CTkEntry(frame, textvariable=variable, height=30, border_width=1, border_color=COLORS["line"], fg_color="#FFFFFF", corner_radius=8).grid(row=1, column=0, sticky="ew", padx=(0, 6))
        self._btn(frame, "Chọn", lambda: self.browse_path(variable, folder), width=60, height=30).grid(row=1, column=1, padx=(0, 6))
        self._btn(frame, "Mở", lambda: self.open_path(variable.get()), color=COLORS["slate"], hover="#344054", width=52, height=30).grid(row=1, column=2)
        return frame

    def _btn(
        self,
        parent: ctk.CTkFrame,
        text: str,
        command: Callable[..., Any],
        color: str = COLORS["blue"],
        hover: str = COLORS["blue2"],
        width: int = 90,
        height: int = 34,
    ) -> ctk.CTkButton:
        return ctk.CTkButton(parent, text=text, command=command, fg_color=color, hover_color=hover, width=width, height=height, corner_radius=8, font=("Segoe UI", 11, "bold"))

    def _switch_tab(self, value: str) -> None:
        for key, frame in self.pages.items():
            if key == value:
                frame.grid()
            else:
                frame.grid_remove()

    def _license_footer_text(self) -> str:
        status = self.license_status
        return f"{status.display_name}  |  v{APP_VERSION}"

    def _load_config(self) -> None:
        raw = read_raw_config()
        stamp = raw.get("stamp", {})
        folders = raw.get("folders", {})
        schedule = raw.get("schedule", {})
        overlay = raw.get("overlay", {})
        viber = raw.get("viber", {})
        updates = raw.get("updates", {})
        license_config = raw.get("license", {})
        self.license_config = dict(license_config) if isinstance(license_config, dict) else {}

        self.group_var.set(str(raw.get("group_name", "")))
        self.address_var.set(str(raw.get("address", "")))
        self.stamp_datetime_var.set(str(stamp.get("datetime_format", "%B %d, %Y %I:%M:%S %p")))
        self.latitude_var.set(str(stamp.get("latitude", "")))
        self.longitude_var.set(str(stamp.get("longitude", "")))
        location_lines = stamp.get("location_lines", [])
        if isinstance(location_lines, list):
            self.location_text.insert("1.0", "\n".join(str(line) for line in location_lines))
        else:
            self.location_text.insert("1.0", str(location_lines or raw.get("address", "")))

        self.normal_var.set(str(resolve_user_path(str(folders.get("normal", "images/normal")))))
        self.friday_var.set(str(resolve_user_path(str(folders.get("friday", "images/friday")))))
        self.output_var.set(str(resolve_user_path(str(folders.get("output", "output")))))
        self.date_format_var.set(str(schedule.get("date_format", "%d/%m/%Y")))
        self.late_window_var.set(str(schedule.get("late_window_minutes", 10)))
        active_days = {str(day) for day in schedule.get("active_days", ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"])}
        for day_name, _label in DAYS:
            self.day_vars[day_name].set(day_name in active_days)

        self.slots = [
            {
                "name": str(slot.get("name", "")),
                "time": str(slot.get("time", "")),
                "image": str(slot.get("image", "")),
                "label": str(slot.get("label", "")),
            }
            for slot in schedule.get("slots", [])
        ]

        blocks = overlay.get("blocks", []) if isinstance(overlay, dict) else []
        block = blocks[0] if isinstance(blocks, list) and blocks else {}
        if not isinstance(block, dict):
            block = {}
        self.overlay_enabled_var.set(bool(overlay.get("enabled", True)) if isinstance(overlay, dict) else True)
        self.font_path_var.set(str(overlay.get("font_path", DEFAULT_FONT_PATH)) if isinstance(overlay, dict) else DEFAULT_FONT_PATH)
        self.overlay_text_var.set(str(block.get("text", DEFAULT_OVERLAY_BLOCK["text"])))
        self.overlay_x_var.set(str(block.get("x", DEFAULT_OVERLAY_BLOCK["x"])))
        self.overlay_y_var.set(str(block.get("y", DEFAULT_OVERLAY_BLOCK["y"])))
        self.overlay_size_var.set(str(block.get("font_size", DEFAULT_OVERLAY_BLOCK["font_size"])))
        self.overlay_fill_var.set(str(block.get("fill", DEFAULT_OVERLAY_BLOCK["fill"])))
        self.overlay_stroke_width_var.set(str(block.get("stroke_width", DEFAULT_OVERLAY_BLOCK["stroke_width"])))
        self.overlay_stroke_fill_var.set(str(block.get("stroke_fill", DEFAULT_OVERLAY_BLOCK["stroke_fill"])))
        self.overlay_anchor_var.set(str(block.get("anchor", DEFAULT_OVERLAY_BLOCK["anchor"])))
        self.overlay_align_var.set(str(block.get("align", DEFAULT_OVERLAY_BLOCK["align"])))
        self.overlay_spacing_var.set(str(block.get("spacing", DEFAULT_OVERLAY_BLOCK["spacing"])))
        self.overlay_shadow_enabled_var.set(bool(block.get("shadow_enabled", DEFAULT_OVERLAY_BLOCK["shadow_enabled"])))
        self.overlay_shadow_dx_var.set(str(block.get("shadow_dx", DEFAULT_OVERLAY_BLOCK["shadow_dx"])))
        self.overlay_shadow_dy_var.set(str(block.get("shadow_dy", DEFAULT_OVERLAY_BLOCK["shadow_dy"])))
        self.overlay_shadow_fill_var.set(str(block.get("shadow_fill", DEFAULT_OVERLAY_BLOCK["shadow_fill"])))
        self.overlay_shadow_opacity_var.set(str(block.get("shadow_opacity", DEFAULT_OVERLAY_BLOCK["shadow_opacity"])))

        exe_path = str(viber.get("exe_path", ""))
        self.viber_exe_var.set(str(resolve_user_path(exe_path)) if exe_path else "")
        self.search_hotkey_var.set(",".join(str(item) for item in viber.get("search_hotkey", ["ctrl", "f"])))
        self.search_wait_var.set(str(viber.get("search_wait_seconds", 1.0)))
        self.search_enter_var.set(str(viber.get("search_enter_count", 1)))
        self.press_enter_var.set(bool(viber.get("press_enter_to_send", True)))
        self.send_original_as_file_var.set(bool(viber.get("send_original_as_file", True)))
        self.preview_wait_var.set(str(viber.get("preview_wait_seconds", 2.0)))
        self.wait_seconds_var.set(str(viber.get("wait_seconds", 1.5)))
        self.pause_seconds_var.set(str(viber.get("pause_seconds", 0.35)))

        self.update_enabled_var.set(bool(updates.get("enabled", True)))
        self.update_auto_check_var.set(bool(updates.get("auto_check_on_start", True)))
        self.update_auto_install_var.set(bool(updates.get("auto_download_install", False)))
        self.update_repo_var.set(str(updates.get("repo", "")))
        self.update_api_url_var.set(str(updates.get("release_api_url", "")))
        self.update_manifest_url_var.set(str(updates.get("manifest_url", "")))
        self.update_keyword_var.set(str(updates.get("asset_keyword", "AutoViber")))
        self.log("Đã tải cấu hình.")

    def collect_config_dict(self) -> dict[str, Any]:
        slots: list[dict[str, str]] = []
        for slot in self.slots:
            engine.parse_time(slot["time"])
            slots.append(
                {
                    "name": slot["name"].strip(),
                    "time": slot["time"].strip(),
                    "image": slot["image"].strip(),
                    "label": slot["label"].strip() or slot["name"].strip().upper(),
                }
            )
        if not slots:
            raise engine.ConfigError("Cần ít nhất một khung giờ.")
        active_days = [day_name for day_name, _label in DAYS if self.day_vars[day_name].get()]
        if not active_days:
            raise engine.ConfigError("Cần chọn ít nhất một ngày hoạt động.")
        location_lines = [line.strip() for line in self.location_text.get("1.0", "end").splitlines() if line.strip()]
        return {
            "group_name": self.group_var.get().strip(),
            "address": self.address_var.get().strip(),
            "stamp": {
                "datetime_format": self.stamp_datetime_var.get().strip() or "%B %d, %Y %I:%M:%S %p",
                "latitude": self.latitude_var.get().strip(),
                "longitude": self.longitude_var.get().strip(),
                "location_lines": location_lines,
            },
            "folders": {
                "normal": normalize_config_path(self.normal_var.get()),
                "friday": normalize_config_path(self.friday_var.get()),
                "output": normalize_config_path(self.output_var.get()),
            },
            "schedule": {
                "active_days": active_days,
                "date_format": self.date_format_var.get().strip() or "%d/%m/%Y",
                "late_window_minutes": int_from(self.late_window_var.get(), "Trễ tối đa phút"),
                "slots": slots,
            },
            "overlay": {
                "enabled": bool(self.overlay_enabled_var.get()),
                "font_path": self.font_path_var.get().strip() or DEFAULT_FONT_PATH,
                "blocks": [
                    {
                        "text": self.overlay_text_var.get().strip() or DEFAULT_OVERLAY_BLOCK["text"],
                        "x": self.overlay_x_var.get().strip() or DEFAULT_OVERLAY_BLOCK["x"],
                        "y": self.overlay_y_var.get().strip() or DEFAULT_OVERLAY_BLOCK["y"],
                        "font_size": self.overlay_size_var.get().strip() or DEFAULT_OVERLAY_BLOCK["font_size"],
                        "fill": self.overlay_fill_var.get().strip() or DEFAULT_OVERLAY_BLOCK["fill"],
                        "stroke_width": int_from(self.overlay_stroke_width_var.get(), "Viền chữ"),
                        "stroke_fill": self.overlay_stroke_fill_var.get().strip() or DEFAULT_OVERLAY_BLOCK["stroke_fill"],
                        "anchor": self.overlay_anchor_var.get().strip() or DEFAULT_OVERLAY_BLOCK["anchor"],
                        "align": self.overlay_align_var.get().strip() or DEFAULT_OVERLAY_BLOCK["align"],
                        "spacing": int_from(self.overlay_spacing_var.get(), "Spacing"),
                        "shadow_enabled": bool(self.overlay_shadow_enabled_var.get()),
                        "shadow_dx": int_from(self.overlay_shadow_dx_var.get(), "Shadow X"),
                        "shadow_dy": int_from(self.overlay_shadow_dy_var.get(), "Shadow Y"),
                        "shadow_fill": self.overlay_shadow_fill_var.get().strip() or DEFAULT_OVERLAY_BLOCK["shadow_fill"],
                        "shadow_opacity": int_from(self.overlay_shadow_opacity_var.get(), "Shadow opacity"),
                    }
                ],
            },
            "viber": {
                "exe_path": normalize_config_path(self.viber_exe_var.get(), allow_relative=False),
                "search_hotkey": [part.strip() for part in self.search_hotkey_var.get().split(",") if part.strip()],
                "search_wait_seconds": float_from(self.search_wait_var.get(), "Search wait"),
                "search_enter_count": int_from(self.search_enter_var.get(), "Enter count"),
                "press_enter_to_send": self.press_enter_var.get(),
                "send_original_as_file": self.send_original_as_file_var.get(),
                "preview_wait_seconds": float_from(self.preview_wait_var.get(), "Preview wait"),
                "wait_seconds": float_from(self.wait_seconds_var.get(), "Open wait"),
                "pause_seconds": float_from(self.pause_seconds_var.get(), "Pause"),
            },
            "updates": {
                "enabled": self.update_enabled_var.get(),
                "repo": self.update_repo_var.get().strip(),
                "release_api_url": self.update_api_url_var.get().strip(),
                "manifest_url": self.update_manifest_url_var.get().strip(),
                "asset_keyword": self.update_keyword_var.get().strip(),
                "auto_check_on_start": self.update_auto_check_var.get(),
                "auto_download_install": self.update_auto_install_var.get(),
            },
            "license": dict(self.license_config),
        }

    def build_engine_config(self) -> engine.AppConfig:
        data = self.collect_config_dict()
        slots = [
            engine.Slot(
                name=slot["name"],
                send_time=engine.parse_time(slot["time"]),
                image_name=slot["image"],
                label=slot["label"],
            )
            for slot in data["schedule"]["slots"]
        ]
        return engine.AppConfig(
            group_name=data["group_name"],
            address=data["address"],
            stamp=data["stamp"],
            normal_folder=resolve_user_path(data["folders"]["normal"]),
            friday_folder=resolve_user_path(data["folders"]["friday"]),
            output_folder=resolve_user_path(data["folders"]["output"]),
            active_days=set(data["schedule"]["active_days"]),
            date_format=data["schedule"]["date_format"],
            late_window_minutes=data["schedule"]["late_window_minutes"],
            slots=slots,
            overlay_enabled=data["overlay"]["enabled"],
            font_path=data["overlay"]["font_path"],
            overlays=data["overlay"]["blocks"],
            viber=data["viber"],
        )

    def save_config(self, silent: bool = False) -> bool:
        try:
            data = self.collect_config_dict()
            write_config(CONFIG_PATH, data)
            engine.load_config(CONFIG_PATH)
            self._expand_path_fields()
            self._refresh_slots()
            self._refresh_status()
            self.log("Đã lưu cấu hình.")
            if not silent:
                messagebox.showinfo(APP_NAME, "Đã lưu cấu hình.")
            return True
        except Exception as exc:
            self.log(f"Lỗi lưu cấu hình: {exc}")
            if not silent:
                messagebox.showerror(APP_NAME, str(exc))
            return False

    def _refresh_slots(self) -> None:
        for frame in [self.main_slots_frame, self.config_slots_frame]:
            for child in frame.winfo_children():
                child.destroy()
            self._slot_header(frame).grid(row=0, column=0, sticky="ew", pady=(0, 4))
            for index, slot in enumerate(self.slots, start=1):
                self._slot_row(frame, index - 1, slot).grid(row=index, column=0, sticky="ew", pady=2)
        values = [slot["name"] for slot in self.slots]
        self.preview_slot_combo.configure(values=values)
        if values and self.preview_slot_var.get() not in values:
            self.preview_slot_var.set(values[0])

    def _slot_header(self, parent: ctk.CTkFrame) -> ctk.CTkFrame:
        row = ctk.CTkFrame(parent, fg_color="#EEF2F7", corner_radius=8)
        for col, weight in enumerate([1, 1, 2, 1]):
            row.grid_columnconfigure(col, weight=weight, uniform="slot")
        for col, text in enumerate(["Tên", "Giờ", "File ảnh", "Check in"]):
            ctk.CTkLabel(row, text=text, text_color="#344054", font=("Segoe UI", 10, "bold"), anchor="w").grid(row=0, column=col, sticky="ew", padx=10, pady=8)
        return row

    def _slot_row(self, parent: ctk.CTkFrame, index: int, slot: dict[str, str]) -> ctk.CTkFrame:
        selected = index == self.selected_slot_index
        row = ctk.CTkFrame(parent, fg_color="#EAF2FF" if selected else "#FFFFFF", border_width=1, border_color="#BFDBFE" if selected else COLORS["line"], corner_radius=8)
        for col, weight in enumerate([1, 1, 2, 1]):
            row.grid_columnconfigure(col, weight=weight, uniform="slot")
        for col, value in enumerate([slot["name"], slot["time"], slot["image"], slot["label"]]):
            label = ctk.CTkLabel(row, text=value, text_color=COLORS["text"], font=("Segoe UI", 11), anchor="w")
            label.grid(row=0, column=col, sticky="ew", padx=10, pady=8)
            label.bind("<Button-1>", lambda _event, idx=index: self.select_slot(idx))
            label.bind("<Double-Button-1>", lambda _event, idx=index: self.edit_slot_from_row(idx))
        row.bind("<Button-1>", lambda _event, idx=index: self.select_slot(idx))
        row.bind("<Double-Button-1>", lambda _event, idx=index: self.edit_slot_from_row(idx))
        return row

    def select_slot(self, index: int) -> None:
        self.selected_slot_index = index
        slot = self.slots[index]
        self.slot_name_var.set(slot["name"])
        self.slot_time_var.set(slot["time"])
        self.slot_image_var.set(slot["image"])
        self.slot_label_var.set(slot["label"])
        self.preview_slot_var.set(slot["name"])
        self._refresh_slots()

    def edit_slot_from_row(self, index: int) -> None:
        self.select_slot(index)
        self.slot_image_var.set(self.slots[index]["image"])

    def add_slot(self) -> None:
        try:
            slot = self._slot_from_editor()
            self.slots.append(slot)
            self.selected_slot_index = len(self.slots) - 1
            self.preview_slot_var.set(slot["name"])
            self._refresh_slots()
            self._refresh_status()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def update_slot(self) -> None:
        if self.selected_slot_index is None:
            return
        try:
            slot = self._slot_from_editor()
            self.slots[self.selected_slot_index] = slot
            self.preview_slot_var.set(slot["name"])
            self._refresh_slots()
            self._refresh_status()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def remove_slot(self) -> None:
        if self.selected_slot_index is None:
            return
        del self.slots[self.selected_slot_index]
        self.selected_slot_index = None
        self._refresh_slots()
        self._refresh_status()

    def _slot_from_editor(self) -> dict[str, str]:
        raw_name = self.slot_name_var.get().strip()
        time_text = self.slot_time_var.get().strip()
        image_name = self.slot_image_var.get().strip()
        label = self.slot_label_var.get().strip()
        if not image_name:
            raise engine.ConfigError("File ảnh không được trống.")
        name = raw_name or Path(image_name).stem
        if not time_text:
            time_text = engine.label_from_image_name(image_name)
        engine.parse_time(time_text)
        check_in = label or engine.label_from_image_name(image_name) or name.upper()
        return {"name": name, "time": time_text, "image": image_name, "label": check_in}

    def apply_stamp_preset(self) -> None:
        self.stamp_datetime_var.set("%B %d, %Y %I:%M:%S %p")
        self._set_default_overlay_vars()

    def _set_default_overlay_vars(self) -> None:
        self.overlay_enabled_var.set(True)
        self.font_path_var.set(DEFAULT_FONT_PATH)
        self.overlay_text_var.set(str(DEFAULT_OVERLAY_BLOCK["text"]))
        self.overlay_x_var.set(str(DEFAULT_OVERLAY_BLOCK["x"]))
        self.overlay_y_var.set(str(DEFAULT_OVERLAY_BLOCK["y"]))
        self.overlay_size_var.set(str(DEFAULT_OVERLAY_BLOCK["font_size"]))
        self.overlay_fill_var.set(str(DEFAULT_OVERLAY_BLOCK["fill"]))
        self.overlay_stroke_width_var.set(str(DEFAULT_OVERLAY_BLOCK["stroke_width"]))
        self.overlay_stroke_fill_var.set(str(DEFAULT_OVERLAY_BLOCK["stroke_fill"]))
        self.overlay_anchor_var.set(str(DEFAULT_OVERLAY_BLOCK["anchor"]))
        self.overlay_align_var.set(str(DEFAULT_OVERLAY_BLOCK["align"]))
        self.overlay_spacing_var.set(str(DEFAULT_OVERLAY_BLOCK["spacing"]))
        self.overlay_shadow_enabled_var.set(bool(DEFAULT_OVERLAY_BLOCK["shadow_enabled"]))
        self.overlay_shadow_dx_var.set(str(DEFAULT_OVERLAY_BLOCK["shadow_dx"]))
        self.overlay_shadow_dy_var.set(str(DEFAULT_OVERLAY_BLOCK["shadow_dy"]))
        self.overlay_shadow_fill_var.set(str(DEFAULT_OVERLAY_BLOCK["shadow_fill"]))
        self.overlay_shadow_opacity_var.set(str(DEFAULT_OVERLAY_BLOCK["shadow_opacity"]))

    def _refresh_status(self) -> None:
        try:
            self.license_config = read_license_config()
            self.license_status = auth.license_status(self.license_config)
            self.license_footer.configure(text=self._license_footer_text())
            config = self.build_engine_config()
            self.group_summary.value_label.configure(text=config.group_name or "Chưa cấu hình")  # type: ignore[attr-defined]
            self.slot_summary.value_label.configure(text=f"{len(config.slots)} slot")  # type: ignore[attr-defined]
            now = datetime.now()
            upcoming = [
                slot
                for slot in sorted(config.slots, key=lambda item: item.send_time)
                if datetime.combine(now.date(), slot.send_time) >= now
            ]
            text = f"{upcoming[0].send_time:%H:%M} {upcoming[0].name}" if upcoming else "-"
            self.next_summary.value_label.configure(text=text)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _preview_now(self) -> datetime:
        try:
            parsed = date.fromisoformat(self.preview_date_var.get().strip())
        except ValueError as exc:
            raise engine.ConfigError("Ngày test cần đúng dạng YYYY-MM-DD.") from exc
        return datetime.combine(parsed, datetime.now().time())

    def selected_slot(self, config: engine.AppConfig) -> engine.Slot:
        name = self.preview_slot_var.get().strip()
        if not name:
            raise engine.ConfigError("Chưa chọn khung giờ.")
        return engine.find_slot(config, name)

    def ensure_license_active(self, notify: bool = True) -> bool:
        self.license_config = read_license_config()
        self.license_status = auth.license_status(self.license_config)
        self.license_footer.configure(text=self._license_footer_text())
        if self.license_status.active:
            self.license_warning_shown = False
            return True
        self.stop_scheduler()
        if notify:
            messagebox.showerror(APP_NAME, self.license_status.reason or "License không hợp lệ.")
        return False

    def render_preview(self) -> None:
        if not self.ensure_license_active():
            return
        try:
            config = self.build_engine_config()
            now = self._preview_now()
            rendered: list[tuple[engine.Slot, Path, Path]] = []
            for slot in sorted(config.slots, key=lambda item: item.send_time):
                image_path = engine.render_image(config, slot, now)
                rendered.append((slot, image_path, self._source_path_for_slot(config, slot, now)))
            self._display_preview_gallery(rendered)
            if rendered:
                self.current_preview_path = rendered[0][1]
                self.preview_path_label.configure(text=f"{len(rendered)} ảnh preview - {now:%Y-%m-%d}")
            self.log(f"Render preview: {len(rendered)} ảnh")
        except Exception as exc:
            self.log(f"Lỗi render: {exc}")
            messagebox.showerror(APP_NAME, str(exc))

    def _set_preview_path(self, image_path: Path) -> None:
        self.current_preview_path = image_path
        self.preview_path_label.configure(text=str(image_path))
        try:
            config = self.build_engine_config()
            slot = self.selected_slot(config)
            self._display_preview_gallery([(slot, image_path, self._source_path_for_slot(config, slot, self._preview_now()))])
        except Exception:
            pass

    def _source_path_for_slot(self, config: engine.AppConfig, slot: engine.Slot, now: datetime) -> Path:
        return engine.source_image_path(config, slot, now)

    def _display_preview_gallery(self, rendered: list[tuple[engine.Slot, Path, Path]]) -> None:
        for child in self.preview_gallery.winfo_children():
            child.destroy()
        self.preview_images.clear()
        if not rendered:
            ctk.CTkLabel(
                self.preview_gallery,
                text="Chưa có preview",
                text_color="#D0D5DD",
                font=("Segoe UI", 13, "bold"),
            ).grid(row=0, column=0, sticky="nsew", padx=16, pady=22)
            return

        try:
            name_to_index = {slot["name"]: idx for idx, slot in enumerate(self.slots)}
            for row_index, (slot, image_path, source_path) in enumerate(rendered):
                item = ctk.CTkFrame(self.preview_gallery, fg_color="#111827", border_width=1, border_color="#344054", corner_radius=10)
                item.grid(row=row_index, column=0, sticky="ew", padx=8, pady=(8 if row_index == 0 else 4, 4))
                item.grid_columnconfigure(1, weight=1)

                image = Image.open(image_path).convert("RGB")
                image.thumbnail((128, 90), Image.Resampling.LANCZOS)
                preview_image = ctk.CTkImage(light_image=image, dark_image=image, size=image.size)
                self.preview_images.append(preview_image)
                img_label = ctk.CTkLabel(item, text="", image=preview_image, fg_color="#0B1220", corner_radius=8)
                img_label.grid(row=0, column=0, rowspan=2, padx=8, pady=8)

                ctk.CTkLabel(
                    item,
                    text=f"{slot.name}  |  {slot.send_time:%H:%M}\n{slot.image_name}\n{image_path.name}",
                    text_color="#F9FAFB",
                    font=("Segoe UI", 10, "bold"),
                    anchor="w",
                    justify="left",
                ).grid(row=0, column=1, sticky="ew", padx=(0, 10), pady=(10, 3))

                buttons = ctk.CTkFrame(item, fg_color="transparent")
                buttons.grid(row=1, column=1, sticky="w", padx=(0, 10), pady=(0, 10))
                self._btn(buttons, "Mở ảnh", lambda path=source_path: self.open_path(str(path)), color=COLORS["slate"], hover="#344054", width=64, height=28).pack(side="left", padx=(0, 5))
                self._btn(buttons, "Output", lambda path=image_path: self.open_path(str(path)), color=COLORS["blue"], hover=COLORS["blue2"], width=66, height=28).pack(side="left")

                if slot.name in name_to_index:
                    idx = name_to_index[slot.name]
                    item.bind("<Button-1>", lambda _event, index=idx: self.select_slot(index))
                    img_label.bind("<Button-1>", lambda _event, index=idx: self.select_slot(index))
        except Exception as exc:
            self.log(f"Lỗi hiển thị preview: {exc}")

    def open_selected_source_image(self) -> None:
        try:
            config = self.build_engine_config()
            slot = self.selected_slot(config)
            path = self._source_path_for_slot(config, slot, self._preview_now())
            if not path.exists():
                raise engine.ConfigError(f"Không tìm thấy file ảnh: {path}")
            self.open_path(str(path))
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def send_test_selected(self) -> None:
        if not self.ensure_license_active():
            return
        try:
            config = self.build_engine_config()
            slot = self.selected_slot(config)
            now = self._preview_now()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.log(f"Đang gửi thử sang Viber: {slot.name}")
        self._run_worker(self._send_selected_worker, config, slot, now, False)

    def _send_selected_worker(self, config: engine.AppConfig, slot: engine.Slot, now: datetime, dry_run: bool) -> None:
        image_path = engine.send_slot(config, slot, dry_run=dry_run, mark=False, now=now)
        self.after(0, lambda: self._set_preview_path(image_path))
        self.log(("Dry run" if dry_run else "Đã gửi") + f": {image_path}")

    def start_scheduler(self) -> None:
        if self.scheduler_thread and self.scheduler_thread.is_alive():
            return
        if not self.ensure_license_active():
            return
        if not self.save_config(silent=True):
            return
        try:
            config = self.build_engine_config()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.scheduler_stop.clear()
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop, args=(config,), daemon=True)
        self.scheduler_thread.start()
        self.status_pill.configure(text="Đang chạy", fg_color="#E7F8F0", text_color=COLORS["green"])
        self.log("Scheduler started.")

    def stop_scheduler(self) -> None:
        self.scheduler_stop.set()
        self.status_pill.configure(text="Đang dừng", fg_color="#EEF2F6", text_color=COLORS["slate"])
        self.log("Scheduler stop requested.")

    def _scheduler_loop(self, config: engine.AppConfig) -> None:
        while not self.scheduler_stop.is_set():
            current = datetime.now()
            try:
                status = auth.license_status(read_license_config())
                if not status.active:
                    self.log(f"Scheduler stopped: license không hợp lệ ({status.reason})")
                    self.scheduler_stop.set()
                    break
                for slot in engine.due_slots(config, current):
                    if self.scheduler_stop.is_set():
                        break
                    self.log(f"Đến giờ gửi: {slot.name}")
                    image_path = engine.send_slot(config, slot, dry_run=False, mark=True, now=current)
                    self.log(f"Đã gửi theo lịch: {image_path}")
            except Exception as exc:
                self.log(f"Lỗi scheduler: {exc}")
            for _ in range(20):
                if self.scheduler_stop.wait(1):
                    break
        self.log("Scheduler stopped.")
        self.after(0, lambda: self.status_pill.configure(text="Đang dừng", fg_color="#EEF2F6", text_color=COLORS["slate"]))

    def hide_to_tray(self) -> None:
        self.withdraw()
        self._ensure_tray_icon()
        self.log("Ứng dụng đang chạy ngầm dưới system tray.")

    def _ensure_tray_icon(self) -> None:
        if self.tray_icon is not None:
            return
        try:
            import pystray
        except ImportError:
            self.deiconify()
            messagebox.showerror(APP_NAME, "Thiếu pystray. Chạy scripts\\setup.ps1 để cài dependency.")
            return

        if LOGO_PATH.exists():
            image = Image.open(LOGO_PATH).convert("RGB").resize((64, 64), Image.Resampling.LANCZOS)
        else:
            image = Image.new("RGB", (64, 64), COLORS["blue"])
            draw = ImageDraw.Draw(image)
            draw.rectangle((0, 0, 63, 63), fill=COLORS["blue"])
            draw.text((18, 20), "AV", fill="white")

        menu = pystray.Menu(
            pystray.MenuItem("Mở Auto Viber Pro", lambda _icon, _item: self.after(0, self.show_from_tray)),
            pystray.MenuItem("Chạy lịch", lambda _icon, _item: self.after(0, self.start_scheduler)),
            pystray.MenuItem("Dừng lịch", lambda _icon, _item: self.after(0, self.stop_scheduler)),
            pystray.MenuItem("Thoát", lambda _icon, _item: self.after(0, self.quit_app)),
        )
        self.tray_icon = pystray.Icon("AutoViberPro", image, APP_NAME, menu)
        self.tray_thread = threading.Thread(target=self.tray_icon.run, daemon=True)
        self.tray_thread.start()

    def show_from_tray(self) -> None:
        self.deiconify()
        self.lift()
        self.focus_force()

    def quit_app(self) -> None:
        self.scheduler_stop.set()
        if self.tray_icon is not None:
            self.tray_icon.stop()
            self.tray_icon = None
        self.destroy()

    def on_close(self) -> None:
        if self.background_var.get() or (self.scheduler_thread and self.scheduler_thread.is_alive()):
            self.hide_to_tray()
        else:
            self.quit_app()

    def browse_path(self, variable: tk.StringVar, folder: bool) -> None:
        current_path = resolve_user_path(variable.get() or ".")
        initial_dir = current_path if folder or not current_path.suffix else current_path.parent
        selected = filedialog.askdirectory(initialdir=str(initial_dir)) if folder else filedialog.askopenfilename(initialdir=str(initial_dir))
        if selected:
            variable.set(str(resolve_user_path(selected)))

    def _expand_path_fields(self) -> None:
        for variable in [self.normal_var, self.friday_var, self.output_var]:
            if variable.get().strip():
                variable.set(str(resolve_user_path(variable.get())))
        if self.viber_exe_var.get().strip():
            self.viber_exe_var.set(str(resolve_user_path(self.viber_exe_var.get())))

    def open_path(self, value: str) -> None:
        path = resolve_user_path(value)
        try:
            if path.suffix:
                subprocess.Popen(["explorer", "/select,", str(path)])
            else:
                path.mkdir(parents=True, exist_ok=True)
                subprocess.Popen(["explorer", str(path)])
        except Exception as exc:
            self.log(f"Không mở được {path}: {exc}")

    def choose_color(self, variable: tk.StringVar) -> None:
        color = colorchooser.askcolor(color=variable.get() or "#FFFFFF")
        if color and color[1]:
            variable.set(color[1])

    def update_config_dict(self) -> dict[str, Any]:
        return self.collect_config_dict()["updates"]

    def check_update_clicked(self) -> None:
        try:
            update_config = self.update_config_dict()
            if not self._has_update_source(update_config):
                raise updater.UpdateError("Chưa cấu hình cập nhật trong file config.toml.")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.update_status_label.configure(text="Đang kiểm tra...")
        self._run_worker(self._check_update_worker, update_config, False)

    def _startup_update_check(self) -> None:
        try:
            update_config = self.update_config_dict()
        except Exception:
            return
        if not update_config.get("enabled") or not update_config.get("auto_check_on_start"):
            return
        if not self._has_update_source(update_config):
            self.log("Bỏ qua kiểm tra update: chưa cấu hình trong file.")
            return
        self._run_worker(self._check_update_worker, update_config, True)

    def _has_update_source(self, update_config: dict[str, Any]) -> bool:
        return bool(update_config.get("repo") or update_config.get("release_api_url") or update_config.get("manifest_url"))

    def _check_update_worker(self, update_config: dict[str, Any], from_startup: bool) -> None:
        release = updater.check_for_update(update_config)
        self.latest_release = release
        self.after(0, lambda: self._show_release(release))
        if release.is_newer:
            self.log(f"Có bản mới: v{release.version}")
            if update_config.get("auto_download_install"):
                self._download_install_release(release, update_config)
            else:
                self.after(0, lambda: self._prompt_update_install(release, update_config))
        else:
            self.log("Phần mềm đang ở phiên bản mới nhất.")
            if not from_startup:
                self.after(0, lambda: messagebox.showinfo(APP_NAME, "Phần mềm đang ở phiên bản mới nhất."))

    def _show_release(self, release: updater.ReleaseInfo) -> None:
        status = f"Có bản mới v{release.version}" if release.is_newer else f"Đang dùng v{APP_VERSION}"
        self.update_status_label.configure(text=status)

    def _prompt_update_install(self, release: updater.ReleaseInfo, update_config: dict[str, Any]) -> None:
        if messagebox.askyesno(APP_NAME, f"Có bản mới v{release.version}. Tải và cài đặt ngay?"):
            self._run_worker(self._download_install_release, release, update_config)

    def install_latest_clicked(self) -> None:
        try:
            update_config = self.update_config_dict()
            release = self.latest_release or updater.check_for_update(update_config)
            if not release.is_newer:
                messagebox.showinfo(APP_NAME, "Không có bản mới hơn để cài.")
                return
            if not messagebox.askyesno(APP_NAME, f"Tải và cài bản v{release.version} ngay?"):
                return
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self._run_worker(self._download_install_release, release, update_config)

    def _download_install_release(self, release: updater.ReleaseInfo, update_config: dict[str, Any]) -> None:
        asset = updater.choose_asset(release, update_config)
        self.log(f"Đang tải update: {asset.name}")
        path = updater.download_asset(asset)
        self.log(f"Đã tải update: {path}")
        updater.install_update(path)

    def open_latest_release(self) -> None:
        if self.latest_release and self.latest_release.html_url:
            webbrowser.open(self.latest_release.html_url)

    def install_startup(self) -> None:
        self._run_worker(self._run_script, ROOT / "scripts" / "install_startup_task.ps1")

    def uninstall_startup(self) -> None:
        self._run_worker(self._run_script, ROOT / "scripts" / "uninstall_startup_task.ps1")

    def _run_script(self, script: Path) -> None:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)],
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            timeout=180,
        )
        if result.stdout.strip():
            self.log(result.stdout.strip())
        if result.stderr.strip():
            self.log(result.stderr.strip())
        if result.returncode != 0:
            raise engine.ConfigError(f"Script failed: {script.name}")

    def _run_worker(self, target: Callable[..., Any], *args: Any) -> None:
        def runner() -> None:
            try:
                target(*args)
            except Exception as exc:
                message = str(exc)
                self.log(f"Lỗi: {message}")
                self.after(0, lambda message=message: messagebox.showerror(APP_NAME, message))

        threading.Thread(target=runner, daemon=True).start()

    def _tick(self) -> None:
        self._refresh_status()
        if not self.license_status.active:
            if self.scheduler_thread and self.scheduler_thread.is_alive():
                self.scheduler_stop.set()
                self.status_pill.configure(text="Đang dừng", fg_color="#EEF2F6", text_color=COLORS["slate"])
            if not self.license_warning_shown:
                self.log(f"License không hợp lệ: {self.license_status.reason}")
                self.license_warning_shown = True
        self.after(30_000, self._tick)

    def log(self, message: str) -> None:
        self.log_queue.put(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {message}")

    def _flush_logs(self) -> None:
        while True:
            try:
                line = self.log_queue.get_nowait()
            except queue.Empty:
                break
            self.log_text.insert("end", line + "\n")
            self.log_text.see("end")
        self.after(200, self._flush_logs)


def validate() -> int:
    config = engine.load_config(CONFIG_PATH)
    print(f"OK: {len(config.slots)} slots, group={config.group_name or '(empty)'}, app={APP_VERSION}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} desktop GUI")
    parser.add_argument("--validate", action="store_true", help="Validate config and exit")
    args = parser.parse_args()
    if args.validate:
        return validate()
    login = LoginWindow()
    login.mainloop()
    if not login.authenticated:
        return 0
    app = AutoViberCompact()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
