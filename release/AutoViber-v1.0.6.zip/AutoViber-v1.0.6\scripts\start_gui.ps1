$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
$Python = Join-Path $Root ".venv\Scripts\python.exe"
$App = Join-Path $Root "auto_viber_gui.py"

if (-not (Test-Path $Python)) {
    & (Join-Path $Root "scripts\setup.ps1")
}

Set-Location $Root
& $Python $App
