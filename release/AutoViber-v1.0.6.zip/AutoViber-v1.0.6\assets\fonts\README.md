# Font Folder

Put `SF-Pro-Text-Regular.otf` in this folder to render the image stamp with San Francisco SF Pro Text Regular.

If the font file is missing, Auto Viber Pro falls back to a regular Windows system font.
