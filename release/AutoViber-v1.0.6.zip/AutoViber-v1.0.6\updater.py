from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app_version import APP_VERSION


ROOT = Path(__file__).resolve().parent
UPDATES_DIR = ROOT / "updates"


class UpdateError(RuntimeError):
    pass


@dataclass(frozen=True)
class ReleaseAsset:
    name: str
    download_url: str
    size: int


@dataclass(frozen=True)
class ReleaseInfo:
    version: str
    tag: str
    name: str
    body: str
    html_url: str
    assets: list[ReleaseAsset]

    @property
    def is_newer(self) -> bool:
        return compare_versions(self.version, APP_VERSION) > 0


def normalize_version(value: str) -> str:
    text = value.strip()
    if text.lower().startswith("version "):
        text = text[8:].strip()
    if text.lower().startswith("v"):
        text = text[1:].strip()
    return text


def version_parts(value: str) -> list[int]:
    normalized = normalize_version(value)
    matches = re.findall(r"\d+", normalized)
    return [int(item) for item in matches[:4]] or [0]


def compare_versions(left: str, right: str) -> int:
    left_parts = version_parts(left)
    right_parts = version_parts(right)
    length = max(len(left_parts), len(right_parts))
    left_parts.extend([0] * (length - len(left_parts)))
    right_parts.extend([0] * (length - len(right_parts)))
    if left_parts > right_parts:
        return 1
    if left_parts < right_parts:
        return -1
    return 0


def build_release_api_url(update_config: dict[str, Any]) -> str:
    direct_url = str(update_config.get("release_api_url", "")).strip()
    if direct_url:
        return direct_url

    repo = str(update_config.get("repo", "")).strip().strip("/")
    if not repo or "/" not in repo:
        raise UpdateError("Chưa cấu hình repo cập nhật. Ví dụ: phamduy/auto-viber-pro")
    return f"https://api.github.com/repos/{repo}/releases/latest"


def request_json(url: str, timeout: int = 20) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": f"AutoViberPro/{APP_VERSION}",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = response.read().decode("utf-8")
            return json.loads(payload)
    except urllib.error.HTTPError as exc:
        raise UpdateError(f"Không kiểm tra được bản cập nhật: HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        raise UpdateError(f"Không kết nối được máy chủ cập nhật: {exc.reason}") from exc
    except json.JSONDecodeError as exc:
        raise UpdateError("Máy chủ cập nhật trả về dữ liệu không hợp lệ.") from exc


def check_for_update(update_config: dict[str, Any]) -> ReleaseInfo:
    if not bool(update_config.get("enabled", True)):
        raise UpdateError("Chức năng cập nhật đang tắt.")

    manifest_url = str(update_config.get("manifest_url", "")).strip()
    if manifest_url:
        return release_from_manifest(request_json(manifest_url))

    payload = request_json(build_release_api_url(update_config))
    return release_from_github_payload(payload)


def release_from_github_payload(payload: dict[str, Any]) -> ReleaseInfo:
    assets = [
        ReleaseAsset(
            name=str(asset.get("name", "")),
            download_url=str(asset.get("browser_download_url", "")),
            size=int(asset.get("size", 0) or 0),
        )
        for asset in payload.get("assets", [])
        if asset.get("browser_download_url")
    ]
    tag = str(payload.get("tag_name", "")).strip()
    version = normalize_version(tag)
    if not version:
        raise UpdateError("Release mới không có tag version.")
    return ReleaseInfo(
        version=version,
        tag=tag,
        name=str(payload.get("name", tag)),
        body=str(payload.get("body", "")),
        html_url=str(payload.get("html_url", "")),
        assets=assets,
    )


def release_from_manifest(payload: dict[str, Any]) -> ReleaseInfo:
    version = normalize_version(str(payload.get("version", "") or payload.get("tag", "")))
    if not version:
        raise UpdateError("File version không có trường version.")

    assets: list[ReleaseAsset] = []
    raw_assets = payload.get("assets")
    if isinstance(raw_assets, list):
        for asset in raw_assets:
            if not isinstance(asset, dict):
                continue
            url = str(asset.get("url", "") or asset.get("download_url", "")).strip()
            if not url:
                continue
            assets.append(
                ReleaseAsset(
                    name=str(asset.get("name", "") or Path(url).name or "AutoViber-update.zip"),
                    download_url=url,
                    size=int(asset.get("size", 0) or 0),
                )
            )

    single_url = str(payload.get("url", "") or payload.get("download_url", "") or payload.get("asset_url", "")).strip()
    if single_url and not assets:
        assets.append(
            ReleaseAsset(
                name=str(payload.get("asset_name", "") or Path(single_url).name or f"AutoViber-v{version}.zip"),
                download_url=single_url,
                size=int(payload.get("size", 0) or 0),
            )
        )

    return ReleaseInfo(
        version=version,
        tag=str(payload.get("tag", "") or f"v{version}"),
        name=str(payload.get("name", "") or f"Auto Viber Pro v{version}"),
        body=str(payload.get("notes", "") or payload.get("body", "")),
        html_url=str(payload.get("html_url", "") or single_url),
        assets=assets,
    )


def choose_asset(release: ReleaseInfo, update_config: dict[str, Any]) -> ReleaseAsset:
    if not release.assets:
        raise UpdateError("Release mới không có file cài đặt.")

    keyword = str(update_config.get("asset_keyword", "")).strip().lower()
    preferred_suffixes = [".exe", ".msi", ".zip"]
    candidates = release.assets
    if keyword:
        keyword_matches = [asset for asset in candidates if keyword in asset.name.lower()]
        if keyword_matches:
            candidates = keyword_matches

    for suffix in preferred_suffixes:
        for asset in candidates:
            if asset.name.lower().endswith(suffix):
                return asset

    return candidates[0]


def download_asset(asset: ReleaseAsset, target_dir: Path = UPDATES_DIR) -> Path:
    target_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^A-Za-z0-9._ -]+", "_", asset.name).strip() or "update.bin"
    target = target_dir / safe_name
    request = urllib.request.Request(asset.download_url, headers={"User-Agent": f"AutoViberPro/{APP_VERSION}"})
    try:
        with urllib.request.urlopen(request, timeout=60) as response, target.open("wb") as output:
            shutil.copyfileobj(response, output)
    except urllib.error.URLError as exc:
        raise UpdateError(f"Tải bản cập nhật thất bại: {exc.reason}") from exc
    return target


def install_update(asset_path: Path) -> None:
    suffix = asset_path.suffix.lower()
    if suffix == ".exe":
        subprocess.Popen([str(asset_path)], cwd=str(asset_path.parent))
        os._exit(0)
    if suffix == ".msi":
        subprocess.Popen(["msiexec.exe", "/i", str(asset_path)], cwd=str(asset_path.parent))
        os._exit(0)
    if suffix == ".zip":
        if not zipfile.is_zipfile(asset_path):
            raise UpdateError("File update ZIP không hợp lệ.")
        script = ROOT / "scripts" / "apply_update.ps1"
        if not script.exists():
            raise UpdateError(f"Không tìm thấy script cập nhật: {script}")
        subprocess.Popen(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script),
                "-ZipPath",
                str(asset_path),
                "-AppDir",
                str(ROOT),
                "-CurrentPid",
                str(os.getpid()),
            ],
            cwd=str(ROOT),
        )
        os._exit(0)
    raise UpdateError("Chỉ hỗ trợ update bằng .exe, .msi hoặc .zip.")
