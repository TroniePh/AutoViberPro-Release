param(
    [Parameter(Mandatory = $true)]
    [string]$ZipPath,

    [Parameter(Mandatory = $true)]
    [string]$AppDir,

    [Parameter(Mandatory = $true)]
    [int]$CurrentPid
)

$ErrorActionPreference = "Stop"

$ZipPath = (Resolve-Path -LiteralPath $ZipPath).Path
$AppDir = (Resolve-Path -LiteralPath $AppDir).Path
$TempRoot = Join-Path $env:TEMP ("auto-viber-update-" + [guid]::NewGuid().ToString("N"))
$ExtractDir = Join-Path $TempRoot "extract"

$appItem = Get-Item -LiteralPath $AppDir
if (-not $appItem.PSIsContainer) {
    throw "AppDir is not a directory: $AppDir"
}
if ($AppDir.Length -lt 10 -or $AppDir -match '^[A-Za-z]:\\$') {
    throw "Refusing to update unsafe AppDir: $AppDir"
}

New-Item -ItemType Directory -Force -Path $ExtractDir | Out-Null

try {
    try {
        Wait-Process -Id $CurrentPid -Timeout 45 -ErrorAction SilentlyContinue
    } catch {
    }

    Expand-Archive -LiteralPath $ZipPath -DestinationPath $ExtractDir -Force

    $source = $ExtractDir
    $children = Get-ChildItem -LiteralPath $ExtractDir -Force
    if ($children.Count -eq 1 -and $children[0].PSIsContainer) {
        $source = $children[0].FullName
    }

    $backupDir = Join-Path $AppDir ("backup-before-update-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $resolvedBackup = (Resolve-Path -LiteralPath $backupDir).Path
    if (-not $resolvedBackup.StartsWith($AppDir, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Backup directory is outside AppDir: $resolvedBackup"
    }

    $preserve = @(
        "config.toml",
        "images",
        "output",
        "state",
        "logs",
        "updates",
        ".venv"
    )

    Get-ChildItem -LiteralPath $AppDir -Force |
        Where-Object { $preserve -notcontains $_.Name -and $_.Name -notlike "backup-before-update-*" } |
        ForEach-Object {
            Move-Item -LiteralPath $_.FullName -Destination (Join-Path $backupDir $_.Name) -Force
        }

    Get-ChildItem -LiteralPath $source -Force |
        Where-Object { $preserve -notcontains $_.Name } |
        ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $AppDir $_.Name) -Recurse -Force
        }

    $setupScript = Join-Path $AppDir "scripts\setup.ps1"
    if (Test-Path -LiteralPath $setupScript) {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $setupScript
    }

    $startScript = Join-Path $AppDir "scripts\start_gui.ps1"
    Start-Process powershell.exe -ArgumentList @(
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        "`"$startScript`""
    ) -WorkingDirectory $AppDir -WindowStyle Hidden
} finally {
    Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
