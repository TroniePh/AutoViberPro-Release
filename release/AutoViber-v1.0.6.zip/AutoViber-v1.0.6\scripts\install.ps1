$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
$SetupScript = Join-Path $PSScriptRoot "setup.ps1"
$StartCmd = Join-Path $Root "start_gui.cmd"
$IconPath = Join-Path $Root "assets\logo.ico"

if (-not (Test-Path -LiteralPath $SetupScript)) {
    throw "Missing setup script: $SetupScript"
}
if (-not (Test-Path -LiteralPath $StartCmd)) {
    throw "Missing launcher: $StartCmd"
}

Write-Host "Installing Auto Viber Pro..."
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $SetupScript

$Shell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath("Desktop")
$StartMenu = [Environment]::GetFolderPath("Programs")
$StartMenuDir = Join-Path $StartMenu "Auto Viber Pro"
New-Item -ItemType Directory -Force -Path $StartMenuDir | Out-Null

function New-AppShortcut {
    param(
        [Parameter(Mandatory=$true)][string]$Path
    )
    $Shortcut = $Shell.CreateShortcut($Path)
    $Shortcut.TargetPath = $StartCmd
    $Shortcut.WorkingDirectory = $Root
    if (Test-Path -LiteralPath $IconPath) {
        $Shortcut.IconLocation = $IconPath
    }
    $Shortcut.Description = "Auto Viber Pro"
    $Shortcut.Save()
}

New-AppShortcut -Path (Join-Path $Desktop "Auto Viber Pro.lnk")
New-AppShortcut -Path (Join-Path $StartMenuDir "Auto Viber Pro.lnk")

Write-Host "Install completed."
Write-Host "Desktop shortcut: Auto Viber Pro"
