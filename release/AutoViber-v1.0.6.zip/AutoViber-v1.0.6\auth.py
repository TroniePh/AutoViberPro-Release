from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
APP_DATA_ROOT = Path(os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA") or str(ROOT / "state"))
STATE_DIR = APP_DATA_ROOT / "AutoViberPro"
AUTH_STATE_PATH = STATE_DIR / "auth.json"
LEGACY_AUTH_STATE_PATH = ROOT / "state" / "auth.json"

DEFAULT_USERNAME = "admin"
DEFAULT_PASSWORD = "Admin@123"

LICENSE_KEYS = {
    "AVP-PREMIUM-3M-2026-DUY-7K9Q": {"plan": "Premium", "duration_days": 90},
    "AVP-TEST-2026-DUY-X4P8": {"plan": "Test", "duration_days": 7},
    "AVP-LIFETIME-DUY-2026-L9M2": {"plan": "Lifetime", "duration_days": None},
}


class AuthError(RuntimeError):
    pass


@dataclass(frozen=True)
class AuthSession:
    username: str
    must_change_password: bool


@dataclass(frozen=True)
class LicenseStatus:
    active: bool
    plan: str
    key: str
    activated_at: str
    expires_at: str
    reason: str = ""

    @property
    def display_name(self) -> str:
        if not self.active:
            return "Chưa kích hoạt"
        if self.expires_at:
            return f"{self.plan} - hết hạn {self.expires_at[:10]}"
        return self.plan


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().replace(microsecond=0).isoformat()


def parse_iso(value: str) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        return None


def hash_password(password: str, salt: bytes | None = None) -> dict[str, str]:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 150_000)
    return {
        "salt": base64.b64encode(salt).decode("ascii"),
        "hash": base64.b64encode(digest).decode("ascii"),
    }


def verify_password(password: str, stored: dict[str, str]) -> bool:
    try:
        salt = base64.b64decode(stored["salt"])
        expected = base64.b64decode(stored["hash"])
    except Exception:
        return False
    actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 150_000)
    return hmac.compare_digest(actual, expected)


def default_state() -> dict[str, Any]:
    return {
        "users": {
            DEFAULT_USERNAME: {
                "password": hash_password(DEFAULT_PASSWORD),
                "must_change_password": True,
                "created_at": iso_now(),
            }
        },
        "license": {},
    }


def ensure_auth_state() -> dict[str, Any]:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    if not AUTH_STATE_PATH.exists():
        if LEGACY_AUTH_STATE_PATH.exists():
            try:
                state = json.loads(LEGACY_AUTH_STATE_PATH.read_text(encoding="utf-8"))
                write_state(state)
                return state
            except Exception:
                pass
        state = default_state()
        write_state(state)
        return state
    return read_state()


def read_state() -> dict[str, Any]:
    try:
        return json.loads(AUTH_STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        state = default_state()
        write_state(state)
        return state


def write_state(state: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    AUTH_STATE_PATH.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def verify_login(username: str, password: str) -> AuthSession:
    state = ensure_auth_state()
    user = state.get("users", {}).get(username.strip())
    if not user or not verify_password(password, user.get("password", {})):
        raise AuthError("Sai tài khoản hoặc mật khẩu.")
    return AuthSession(username=username.strip(), must_change_password=bool(user.get("must_change_password", False)))


def change_password(username: str, new_password: str) -> None:
    if len(new_password) < 6:
        raise AuthError("Mật khẩu mới cần ít nhất 6 ký tự.")
    state = ensure_auth_state()
    user = state.get("users", {}).get(username)
    if not user:
        raise AuthError("Không tìm thấy tài khoản.")
    user["password"] = hash_password(new_password)
    user["must_change_password"] = False
    user["changed_at"] = iso_now()
    write_state(state)


def normalize_key(key: str) -> str:
    return key.strip().upper().replace(" ", "")


def key_sha256(key: str) -> str:
    return hashlib.sha256(normalize_key(key).encode("utf-8")).hexdigest()


def key_matches(candidate: str, key: str) -> bool:
    text = str(candidate).strip()
    if normalize_key(text) == key:
        return True
    lowered = text.lower()
    if lowered.startswith("sha256:"):
        lowered = lowered.removeprefix("sha256:")
    return lowered == key_sha256(key)


def activate_license(key: str, license_config: dict[str, Any] | None = None) -> LicenseStatus:
    normalized = normalize_key(key)
    info = remote_license_info(normalized, license_config) if online_license_enabled(license_config) else LICENSE_KEYS.get(normalized)
    if not info:
        raise AuthError("License key không hợp lệ.")

    activated = utc_now()
    duration_days = info.get("duration_days")
    expires_at = str(info.get("expires_at", "") or "")
    if not expires_at and duration_days is not None:
        expires_at = (activated + timedelta(days=int(duration_days))).replace(microsecond=0).isoformat()

    state = ensure_auth_state()
    state["license"] = {
        "key": normalized,
        "plan": str(info.get("plan", "Premium")),
        "activated_at": activated.replace(microsecond=0).isoformat(),
        "expires_at": expires_at,
        "online": online_license_enabled(license_config),
    }
    write_state(state)
    return license_status(license_config)


def license_status(license_config: dict[str, Any] | None = None) -> LicenseStatus:
    state = ensure_auth_state()
    license_data = state.get("license") or {}
    key = str(license_data.get("key", ""))
    plan = str(license_data.get("plan", ""))
    activated_at = str(license_data.get("activated_at", ""))
    expires_at = str(license_data.get("expires_at", ""))

    if not key:
        return LicenseStatus(False, "", "", "", "", "Chưa kích hoạt license.")

    if online_license_enabled(license_config):
        try:
            info = remote_license_info(key, license_config)
        except AuthError as exc:
            return LicenseStatus(False, plan, key, activated_at, expires_at, str(exc))
        if not info:
            return LicenseStatus(False, plan, key, activated_at, expires_at, "License không còn hợp lệ trên máy chủ.")
        plan = str(info.get("plan", plan or "Premium"))
        expires_at = str(info.get("expires_at", expires_at) or "")
    elif key not in LICENSE_KEYS:
        return LicenseStatus(False, "", key, activated_at, expires_at, "License key không hợp lệ.")

    expires = parse_iso(expires_at)
    if expires and utc_now() > expires:
        return LicenseStatus(False, plan, key, activated_at, expires_at, "License đã hết hạn.")
    return LicenseStatus(True, plan, key, activated_at, expires_at)


def online_license_enabled(license_config: dict[str, Any] | None) -> bool:
    return bool((license_config or {}).get("manifest_url"))


def remote_license_info(key: str, license_config: dict[str, Any] | None) -> dict[str, Any] | None:
    url = str((license_config or {}).get("manifest_url", "")).strip()
    if not url:
        return None
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "AutoViberPro-License"})
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raise AuthError(f"Khong kiem tra duoc license online: HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        raise AuthError(f"Khong kiem tra duoc license online: {getattr(exc, 'reason', exc)}") from exc

    normalized = normalize_key(key)
    try:
        payload = json.loads(raw)
        info = find_key_in_payload(normalized, payload)
        if info and bool(info.get("active", True)):
            return info
        return None
    except json.JSONDecodeError:
        return find_key_in_text(normalized, raw)


def find_key_in_payload(key: str, payload: Any) -> dict[str, Any] | None:
    keys = payload.get("keys", payload) if isinstance(payload, dict) else payload
    if isinstance(keys, dict):
        for raw_key, info in keys.items():
            if key_matches(str(raw_key), key):
                return dict(info) if isinstance(info, dict) else {"plan": str(info or "Premium")}
    if isinstance(keys, list):
        for item in keys:
            if isinstance(item, str) and key_matches(item, key):
                return {"plan": "Premium"}
            if isinstance(item, dict):
                raw_key = str(item.get("key", ""))
                hashed_key = str(item.get("sha256", "") or item.get("hash", "") or item.get("key_hash", ""))
                if (raw_key and key_matches(raw_key, key)) or (hashed_key and key_matches(f"sha256:{hashed_key}", key)):
                    return dict(item)
    return None


def find_key_in_text(key: str, raw: str) -> dict[str, Any] | None:
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in line.split("|")]
        if not key_matches(parts[0], key):
            continue
        return {
            "plan": parts[1] if len(parts) > 1 and parts[1] else "Premium",
            "expires_at": parts[2] if len(parts) > 2 else "",
            "active": True,
        }
    return None
