$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
$Script = Join-Path $Root "scripts\start_auto_viber.ps1"
$TaskName = "Auto Viber Image Sender"

if (-not (Test-Path (Join-Path $Root ".venv\Scripts\python.exe"))) {
    throw "Virtual environment not found. Run scripts\setup.ps1 first."
}

$Action = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$Script`""

$Trigger = New-ScheduledTaskTrigger -AtLogOn
$Settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $Action `
    -Trigger $Trigger `
    -Settings $Settings `
    -Description "Runs the Auto Viber image sender at Windows logon." `
    -Force

Write-Host "Installed startup task: $TaskName"
Write-Host "The PC must be on, logged in, unlocked, and Viber Desktop must be usable."
