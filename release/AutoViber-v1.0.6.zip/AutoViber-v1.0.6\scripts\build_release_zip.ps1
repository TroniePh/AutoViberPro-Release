param(
    [string]$Version = ""
)

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
$Dist = Join-Path $Root "dist"

if ([string]::IsNullOrWhiteSpace($Version)) {
    $versionFile = Join-Path $Root "app_version.py"
    $match = Select-String -Path $versionFile -Pattern 'APP_VERSION\s*=\s*"([^"]+)"' | Select-Object -First 1
    if (-not $match) {
        throw "Could not read APP_VERSION from app_version.py"
    }
    $Version = $match.Matches[0].Groups[1].Value
}

$PackageName = "AutoViber-v$Version"
$PackageDir = Join-Path $Dist $PackageName
$ZipPath = Join-Path $Dist "$PackageName.zip"

New-Item -ItemType Directory -Force -Path $Dist | Out-Null
$resolvedDist = (Resolve-Path -LiteralPath $Dist).Path

if (Test-Path -LiteralPath $PackageDir) {
    $resolvedPackageDir = (Resolve-Path -LiteralPath $PackageDir).Path
    if (-not $resolvedPackageDir.StartsWith($resolvedDist, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to remove package dir outside dist: $resolvedPackageDir"
    }
    Remove-Item -LiteralPath $PackageDir -Recurse -Force
}
if (Test-Path -LiteralPath $ZipPath) {
    Remove-Item -LiteralPath $ZipPath -Force
}

New-Item -ItemType Directory -Force -Path $PackageDir | Out-Null

$exclude = @(
    ".git",
    ".venv",
    "release_publish",
    "__pycache__",
    "backup-before-update-*",
    "dist",
    "keyvib.txt",
    "logs",
    "output",
    "state",
    "updates"
)

Get-ChildItem -LiteralPath $Root -Force |
    Where-Object {
        $name = $_.Name
        -not ($exclude | Where-Object { $name -like $_ })
    } |
    ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $PackageDir $_.Name) -Recurse -Force
    }

Compress-Archive -LiteralPath $PackageDir -DestinationPath $ZipPath -Force
$resolvedPackageDir = (Resolve-Path -LiteralPath $PackageDir).Path
if (-not $resolvedPackageDir.StartsWith($resolvedDist, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to remove package dir outside dist: $resolvedPackageDir"
}
Remove-Item -LiteralPath $PackageDir -Recurse -Force

Write-Host "Release package created:"
Write-Host $ZipPath
Write-Host ""
Write-Host "GitHub release tag should be: v$Version"
Write-Host "Upload asset: $PackageName.zip"
