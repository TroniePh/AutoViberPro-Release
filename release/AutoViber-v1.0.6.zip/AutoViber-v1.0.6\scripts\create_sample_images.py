from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
SLOTS = ["5pm", "6pm", "7pm"]


def font(size: int):
    for path in ["C:/Windows/Fonts/arial.ttf", "arial.ttf"]:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    return ImageFont.load_default()


def make_image(folder: Path, slot: str, title: str, color: tuple[int, int, int]) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    image = Image.new("RGB", (1080, 1080), color)
    draw = ImageDraw.Draw(image)
    draw.rectangle((36, 36, 1044, 1044), outline=(255, 255, 255), width=4)
    draw.text((540, 470), title, fill=(255, 255, 255), font=font(72), anchor="mm")
    draw.text((540, 560), slot.upper(), fill=(255, 255, 255), font=font(48), anchor="mm")
    image.save(folder / f"{slot}.png")


def main() -> None:
    for slot in SLOTS:
        make_image(ROOT / "images" / "normal", slot, "NORMAL TEMPLATE", (42, 82, 116))
        make_image(ROOT / "images" / "friday", slot, "FRIDAY TEMPLATE", (116, 68, 52))
    print("Sample images created.")


if __name__ == "__main__":
    main()
