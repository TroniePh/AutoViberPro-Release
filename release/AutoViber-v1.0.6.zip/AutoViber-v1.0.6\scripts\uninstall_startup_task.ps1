$ErrorActionPreference = "Stop"

$TaskName = "Auto Viber Image Sender"

Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
Write-Host "Removed startup task: $TaskName"
