from __future__ import annotations

import argparse
import ctypes
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import tomllib
from dataclasses import dataclass
from datetime import date, datetime, time as dt_time, timedelta
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config.toml"
STATE_PATH = ROOT / "state" / "sent.json"
DEFAULT_FONT_PATH = "assets/fonts/SF-Pro-Text-Regular.otf"
DEFAULT_FONT_SIZE: int | str = "auto"

WEEKDAY_NAMES = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


class ConfigError(RuntimeError):
    pass


@dataclass(frozen=True)
class Slot:
    name: str
    send_time: dt_time
    image_name: str
    label: str


@dataclass(frozen=True)
class AppConfig:
    group_name: str
    address: str
    stamp: dict[str, Any]
    normal_folder: Path
    friday_folder: Path
    output_folder: Path
    active_days: set[str]
    date_format: str
    late_window_minutes: int
    slots: list[Slot]
    overlay_enabled: bool
    font_path: str
    overlays: list[dict[str, Any]]
    viber: dict[str, Any]


def load_config(path: Path = CONFIG_PATH) -> AppConfig:
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")

    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    schedule = raw.get("schedule", {})
    folders = raw.get("folders", {})
    stamp = raw.get("stamp", {})
    overlay = raw.get("overlay", {})
    viber = raw.get("viber", {})

    slots: list[Slot] = []
    for item in schedule.get("slots", []):
        send_time = parse_time(str(item["time"]))
        image_name = str(item.get("image", f"{item['name']}.png"))
        label = str(item.get("label") or label_from_image_name(image_name))
        slots.append(Slot(name=str(item["name"]), send_time=send_time, image_name=image_name, label=label))

    if not slots:
        raise ConfigError("No schedule.slots configured.")

    active_days = {str(day).lower() for day in schedule.get("active_days", WEEKDAY_NAMES[:6])}
    unknown_days = sorted(active_days.difference(WEEKDAY_NAMES))
    if unknown_days:
        raise ConfigError(f"Unknown weekday names in schedule.active_days: {', '.join(unknown_days)}")

    overlays = list(overlay.get("blocks", []))
    if not overlays:
        overlays = [
            {
                "text": "{stamp_datetime}\n{coordinates}\n{location}",
                "x": "-4.2%",
                "y": "3.0%",
                "font_size": DEFAULT_FONT_SIZE,
                "fill": "#FFFFFF",
                "stroke_width": 1,
                "stroke_fill": "#000000",
                "anchor": "ra",
                "align": "right",
                "spacing": 2,
            },
        ]

    return AppConfig(
        group_name=str(raw.get("group_name", "")).strip(),
        address=str(raw.get("address", "")).strip(),
        stamp=dict(stamp),
        normal_folder=resolve_path(folders.get("normal", "images/normal")),
        friday_folder=resolve_path(folders.get("friday", "images/friday")),
        output_folder=resolve_path(folders.get("output", "output")),
        active_days=active_days,
        date_format=str(schedule.get("date_format", "%d/%m/%Y")),
        late_window_minutes=int(schedule.get("late_window_minutes", 10)),
        slots=slots,
        overlay_enabled=bool(overlay.get("enabled", True)),
        font_path=str(overlay.get("font_path") or DEFAULT_FONT_PATH),
        overlays=overlays,
        viber=dict(viber),
    )


def resolve_path(value: Any) -> Path:
    path = Path(str(value)).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    return path


def parse_time(value: str) -> dt_time:
    value = value.strip().lower()
    match = re.fullmatch(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", value)
    if not match:
        raise ConfigError(f"Invalid time value: {value}")

    hour = int(match.group(1))
    minute = int(match.group(2) or "0")
    suffix = match.group(3)

    if suffix == "pm" and hour != 12:
        hour += 12
    elif suffix == "am" and hour == 12:
        hour = 0

    if not 0 <= hour <= 23 or not 0 <= minute <= 59:
        raise ConfigError(f"Invalid time value: {value}")

    return dt_time(hour=hour, minute=minute)


def label_from_image_name(image_name: str) -> str:
    stem = Path(image_name).stem
    match = re.fullmatch(r"(\d{1,2})(?:[_-]?(\d{2}))?\s*(am|pm)?", stem, re.IGNORECASE)
    if match:
        hour = match.group(1)
        minute = match.group(2)
        suffix = (match.group(3) or "").upper()
        return f"{hour}:{minute}{suffix}" if minute else f"{hour}{suffix}"
    return stem


def today_name(now: datetime | None = None) -> str:
    current = now or datetime.now()
    return WEEKDAY_NAMES[current.weekday()]


def folder_for_day(config: AppConfig, day_name: str) -> Path:
    return config.friday_folder if day_name == "friday" else config.normal_folder


def source_image_path(config: AppConfig, slot: Slot, now: datetime | None = None) -> Path:
    current = now or datetime.now()
    return folder_for_day(config, today_name(current)) / slot.image_name


def find_slot(config: AppConfig, slot_ref: str) -> Slot:
    normalized = slot_ref.strip().lower()
    for slot in config.slots:
        if slot.name.lower() == normalized:
            return slot
        if slot.image_name.lower() == normalized:
            return slot
        if slot.send_time.strftime("%H:%M") == normalized:
            return slot
        if label_from_image_name(slot.image_name).lower() == normalized:
            return slot
    raise ConfigError(f"No slot matches: {slot_ref}")


def display_time_for_slot(slot: Slot) -> dt_time:
    for value in [slot.label, label_from_image_name(slot.image_name), slot.name]:
        try:
            return parse_time(str(value))
        except ConfigError:
            continue
    return slot.send_time


def build_context(config: AppConfig, slot: Slot, now: datetime | None = None) -> dict[str, str]:
    current = now or datetime.now()
    stamp_current = datetime.combine(current.date(), display_time_for_slot(slot))
    stamp_datetime_format = str(config.stamp.get("datetime_format") or "%B %d, %Y at %#I:%M:%S %p")
    latitude = str(config.stamp.get("latitude") or "")
    longitude = str(config.stamp.get("longitude") or "")
    location_lines = config.stamp.get("location_lines")
    if isinstance(location_lines, list):
        location = "\n".join(str(line) for line in location_lines if str(line).strip())
    else:
        location = str(location_lines or config.address)
    return {
        "address": config.address,
        "date": stamp_current.strftime(config.date_format),
        "stamp_datetime": stamp_current.strftime(stamp_datetime_format),
        "latitude": latitude,
        "longitude": longitude,
        "coordinates": f"{latitude} {longitude}".strip(),
        "location": location,
        "slot_name": slot.name,
        "slot_label": slot.label,
        "time": slot.label,
        "slot_time": stamp_current.strftime("%H:%M"),
        "weekday": today_name(current),
    }


def render_image(config: AppConfig, slot: Slot, now: datetime | None = None) -> Path:
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageOps
    except ImportError as exc:
        raise ConfigError("Missing dependency: Pillow. Run scripts/setup.ps1 first.") from exc

    current = now or datetime.now()
    source = source_image_path(config, slot, current)
    if not source.exists():
        raise ConfigError(f"Source image not found: {source}")

    if not config.overlay_enabled:
        return source

    config.output_folder.mkdir(parents=True, exist_ok=True)
    out_name = f"{current:%Y%m%d}_{slot.name}_{source.stem}.png"
    output = config.output_folder / out_name

    context = build_context(config, slot, current)
    base_font_path = config.font_path

    image = ImageOps.exif_transpose(Image.open(source)).convert("RGBA")
    draw = ImageDraw.Draw(image)

    for block in config.overlays:
        text_template = str(block.get("text", ""))
        text = text_template.format(**context)
        x = coordinate_from_config(block.get("x", 0), image.width)
        y = coordinate_from_config(block.get("y", 0), image.height)
        fill = str(block.get("fill", "#111111"))
        font_size = font_size_from_config(block.get("font_size", 34), image.width, image.height)
        font_path = str(block.get("font_path") or base_font_path)
        anchor = str(block.get("anchor", "la"))
        stroke_width = int(block.get("stroke_width", 0))
        stroke_fill = str(block.get("stroke_fill", "#ffffff"))
        align = str(block.get("align", "left"))

        font = load_font(ImageFont, font_path, font_size)
        draw.multiline_text(
            (x, y),
            text,
            fill=fill,
            font=font,
            anchor=anchor,
            spacing=int(block.get("spacing", 6)),
            align=align,
            stroke_width=stroke_width,
            stroke_fill=stroke_fill,
        )

    image.save(output, format="PNG", compress_level=0)
    return output


def load_font(image_font_module: Any, font_path: str, font_size: int) -> Any:
    for candidate in font_candidates(font_path):
        try:
            if candidate.exists():
                return image_font_module.truetype(str(candidate), font_size)
        except OSError:
            continue
    try:
        return image_font_module.truetype("segoeui.ttf", font_size)
    except OSError:
        return image_font_module.load_default()


def font_candidates(font_path: str) -> list[Path]:
    names = [
        font_path,
        DEFAULT_FONT_PATH,
        "assets/fonts/SFProText-Regular.otf",
        "assets/fonts/SF-Pro-Text-Regular.ttf",
        "assets/fonts/SFProText-Regular.ttf",
        "C:/Windows/Fonts/SF-Pro-Text-Regular.otf",
        "C:/Windows/Fonts/SFProText-Regular.otf",
        "C:/Windows/Fonts/SF-Pro-Text-Regular.ttf",
        "C:/Windows/Fonts/SFProText-Regular.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/arial.ttf",
    ]
    candidates: list[Path] = []
    seen: set[str] = set()
    for name in names:
        if not name:
            continue
        path = Path(str(name)).expanduser()
        if not path.is_absolute():
            path = ROOT / path
        key = str(path).lower()
        if key not in seen:
            candidates.append(path)
            seen.add(key)
    return candidates


def coordinate_from_config(value: Any, size: int) -> int:
    text = str(value).strip()
    if text.endswith("%"):
        percent = float(text[:-1]) / 100.0
        offset = int(round(size * percent))
        return size + offset if percent < 0 else offset
    number = int(float(text))
    return size + number if number < 0 else number


def font_size_from_config(value: Any, width: int, height: int) -> int:
    text = str(value).strip().lower()
    if text in {"auto", "camera"}:
        return max(14, int(round(min(width, height) * 0.039)))
    if text.endswith("%"):
        return max(10, int(round(min(width, height) * (float(text[:-1]) / 100.0))))
    return int(float(text))


def read_state() -> dict[str, Any]:
    if not STATE_PATH.exists():
        return {}
    try:
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def write_state(state: dict[str, Any]) -> None:
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def state_key(slot: Slot, current: datetime) -> str:
    return f"{current:%Y-%m-%d}:{slot.name}"


def mark_sent(slot: Slot, image_path: Path, current: datetime) -> None:
    state = read_state()
    state[state_key(slot, current)] = {
        "sent_at": datetime.now().isoformat(timespec="seconds"),
        "image": str(image_path),
    }
    write_state(state)


def already_sent(slot: Slot, current: datetime) -> bool:
    return state_key(slot, current) in read_state()


def due_slots(config: AppConfig, current: datetime) -> list[Slot]:
    if today_name(current) not in config.active_days:
        return []

    result: list[Slot] = []
    for slot in config.slots:
        scheduled = datetime.combine(current.date(), slot.send_time)
        late_by = current - scheduled
        if timedelta(0) <= late_by <= timedelta(minutes=config.late_window_minutes):
            if not already_sent(slot, current):
                result.append(slot)
    return result


def run_scheduler(config: AppConfig, dry_run: bool = False) -> None:
    print("Auto Viber scheduler started.")
    print(f"Group: {config.group_name}")
    print(f"Active days: {', '.join(sorted(config.active_days))}")
    print(f"Late window: {config.late_window_minutes} minutes")
    print("Press Ctrl+C to stop.")

    while True:
        current = datetime.now()
        for slot in due_slots(config, current):
            try:
                send_slot(config, slot, dry_run=dry_run, mark=True)
            except Exception as exc:
                print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] ERROR {slot.name}: {exc}", file=sys.stderr)
        time.sleep(20)


def send_slot(
    config: AppConfig,
    slot: Slot,
    dry_run: bool = False,
    mark: bool = False,
    now: datetime | None = None,
) -> Path:
    current = now or datetime.now()
    image_path = render_image(config, slot, current)
    print(f"Rendered: {image_path}")

    if dry_run:
        print(f"Dry run: would send {image_path} to {config.group_name}")
    else:
        send_image_to_viber(config, image_path)
        print(f"Sent: {image_path}")

    if mark:
        mark_sent(slot, image_path, current)
    return image_path


def send_image_to_viber(config: AppConfig, image_path: Path) -> None:
    if not config.group_name:
        raise ConfigError("group_name is empty in config.toml.")

    try:
        import pyautogui
    except ImportError as exc:
        raise ConfigError("Missing dependency: pyautogui. Run scripts/setup.ps1 first.") from exc

    pyautogui.PAUSE = float(config.viber.get("pause_seconds", 0.35))
    wait_seconds = float(config.viber.get("wait_seconds", 1.5))
    preview_wait_seconds = float(config.viber.get("preview_wait_seconds", 2.0))

    launch_viber(config)
    time.sleep(wait_seconds)
    viber_window = focus_viber_window(pyautogui, timeout_seconds=max(wait_seconds + 4.0, 5.0))
    select_viber_conversation(pyautogui, viber_window, config)

    put_image_on_clipboard(image_path)
    pyautogui.hotkey("ctrl", "v")
    time.sleep(preview_wait_seconds)

    if bool(config.viber.get("press_enter_to_send", True)):
        pyautogui.press("enter")


def launch_viber(config: AppConfig) -> None:
    configured = str(config.viber.get("exe_path", "")).strip()
    if configured:
        exe = resolve_path(configured)
        if not exe.exists():
            raise ConfigError(f"Configured Viber exe_path does not exist: {exe}")
        subprocess.Popen([str(exe)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return

    candidates = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "Viber" / "Viber.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Viber" / "Viber.exe",
        Path(os.environ.get("ProgramFiles", "")) / "Viber" / "Viber.exe",
        Path(os.environ.get("ProgramFiles(x86)", "")) / "Viber" / "Viber.exe",
    ]
    for candidate in candidates:
        if candidate.exists():
            subprocess.Popen([str(candidate)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return

    located = shutil.which("Viber.exe") or shutil.which("viber")
    if located:
        subprocess.Popen([located], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return

    # If Viber is already open, focusing the window may still succeed.


def focus_viber_window(pyautogui_module: Any, timeout_seconds: float = 5.0) -> Any:
    deadline = time.monotonic() + max(timeout_seconds, 0.5)
    while True:
        windows = find_viber_windows(pyautogui_module)

        if windows:
            window = windows[0]
            try:
                if window.isMinimized:
                    window.restore()
                window.activate()
                time.sleep(0.4)
                return window
            except Exception as exc:
                raise ConfigError(f"Không focus được cửa sổ Viber Desktop: {exc}") from exc

        if time.monotonic() >= deadline:
            break
        time.sleep(0.25)

    raise ConfigError(
        "Không tìm thấy cửa sổ Viber Desktop. Hãy mở Viber, đăng nhập tài khoản, "
        "hoặc cấu hình đúng đường dẫn Viber.exe."
    )


def find_viber_windows(pyautogui_module: Any) -> list[Any]:
    try:
        windows = pyautogui_module.getAllWindows()
    except Exception:
        try:
            windows = pyautogui_module.getWindowsWithTitle("Viber")
        except Exception:
            return []

    candidates: list[tuple[tuple[int, int], Any]] = []
    fallbacks: list[tuple[tuple[int, int], Any]] = []
    for window in windows:
        title = str(getattr(window, "title", "") or "").strip()
        lower_title = title.lower()
        if "viber" not in lower_title or "auto viber" in lower_title:
            continue

        area = int(getattr(window, "width", 0) or 0) * int(getattr(window, "height", 0) or 0)
        priority = 0 if lower_title == "rakuten viber" else 1
        process_path = window_process_path(window).lower()
        item = ((priority, -area), window)
        if process_path.endswith("\\viber.exe") or process_path.endswith("/viber.exe"):
            candidates.append(item)
        elif lower_title == "rakuten viber":
            fallbacks.append(item)

    selected = candidates or fallbacks
    selected.sort(key=lambda item: item[0])
    return [window for _score, window in selected]


def window_process_path(window: Any) -> str:
    if os.name != "nt":
        return ""
    hwnd = getattr(window, "_hWnd", None)
    if not hwnd:
        return ""

    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    pid = ctypes.c_ulong()
    try:
        ctypes.windll.user32.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid))
        handle = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
        if not handle:
            return ""
        try:
            size = ctypes.c_ulong(1024)
            buffer = ctypes.create_unicode_buffer(size.value)
            if ctypes.windll.kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)):
                return buffer.value
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    except Exception:
        return ""
    return ""


def select_viber_conversation(pyautogui_module: Any, window: Any, config: AppConfig) -> None:
    # Viber's Ctrl+F searches inside the active chat on current builds, so use the
    # left conversation search field and then place focus in the message input.
    for _ in range(int(config.viber.get("reset_escape_count", 2))):
        pyautogui_module.press("esc")
        time.sleep(0.15)

    search_x = int(config.viber.get("sidebar_search_x", 140))
    search_y = int(config.viber.get("sidebar_search_y", 56))
    pyautogui_module.click(window.left + search_x, window.top + search_y)
    time.sleep(0.2)
    pyautogui_module.hotkey("ctrl", "a")
    put_text_on_clipboard(config.group_name)
    pyautogui_module.hotkey("ctrl", "v")
    time.sleep(float(config.viber.get("search_wait_seconds", 1.0)))

    enter_count = int(config.viber.get("search_enter_count", 1))
    for _ in range(enter_count):
        pyautogui_module.press("enter")
        time.sleep(0.3)

    if bool(config.viber.get("click_first_search_result", True)):
        result_x = int(config.viber.get("chat_result_x", 140))
        result_y = int(config.viber.get("chat_result_y", 200))
        pyautogui_module.click(window.left + result_x, window.top + result_y)
        time.sleep(0.35)

    for _ in range(int(config.viber.get("close_search_escape_count", 1))):
        pyautogui_module.press("esc")
        time.sleep(0.15)

    input_x_ratio = float(config.viber.get("message_input_x_ratio", 0.62))
    input_y_offset = int(config.viber.get("message_input_y_offset", 26))
    input_x = window.left + int(window.width * input_x_ratio)
    input_y = window.top + window.height - input_y_offset
    pyautogui_module.click(input_x, input_y)
    time.sleep(0.25)


def put_image_on_clipboard(path: Path) -> None:
    if os.name != "nt":
        raise ConfigError("Image clipboard paste is only implemented for Windows.")

    try:
        from PIL import Image
    except ImportError as exc:
        raise ConfigError("Missing dependency: Pillow. Run scripts/setup.ps1 first.") from exc

    with Image.open(path) as image:
        bitmap = io.BytesIO()
        image.convert("RGB").save(bitmap, "BMP")
    data = bitmap.getvalue()[14:]

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    CF_DIB = 8
    GMEM_MOVEABLE = 0x0002
    GMEM_ZEROINIT = 0x0040

    user32.OpenClipboard.argtypes = [ctypes.c_void_p]
    user32.OpenClipboard.restype = ctypes.c_bool
    user32.EmptyClipboard.argtypes = []
    user32.EmptyClipboard.restype = ctypes.c_bool
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    user32.SetClipboardData.restype = ctypes.c_void_p
    user32.CloseClipboard.argtypes = []
    user32.CloseClipboard.restype = ctypes.c_bool

    kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.restype = ctypes.c_bool

    if not user32.OpenClipboard(None):
        raise ConfigError("Could not open Windows clipboard.")

    handle = None
    try:
        user32.EmptyClipboard()
        handle = kernel32.GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT, len(data))
        if not handle:
            raise ConfigError("Could not allocate clipboard memory.")
        locked = kernel32.GlobalLock(handle)
        if not locked:
            raise ConfigError("Could not lock clipboard memory.")
        ctypes.memmove(locked, data, len(data))
        kernel32.GlobalUnlock(handle)
        if not user32.SetClipboardData(CF_DIB, handle):
            raise ConfigError("Could not set image clipboard data.")
        handle = None
    finally:
        user32.CloseClipboard()


def put_file_on_clipboard(path: Path) -> None:
    if os.name != "nt":
        raise ConfigError("File clipboard paste is only implemented for Windows.")

    absolute_path = str(path.resolve())
    data = build_cf_hdrop_data([absolute_path])

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    CF_HDROP = 15
    GMEM_MOVEABLE = 0x0002
    GMEM_ZEROINIT = 0x0040

    user32.OpenClipboard.argtypes = [ctypes.c_void_p]
    user32.OpenClipboard.restype = ctypes.c_bool
    user32.EmptyClipboard.argtypes = []
    user32.EmptyClipboard.restype = ctypes.c_bool
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    user32.SetClipboardData.restype = ctypes.c_void_p
    user32.CloseClipboard.argtypes = []
    user32.CloseClipboard.restype = ctypes.c_bool

    kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.restype = ctypes.c_bool

    if not user32.OpenClipboard(None):
        raise ConfigError("Could not open Windows clipboard.")

    handle = None
    try:
        user32.EmptyClipboard()
        handle = kernel32.GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT, len(data))
        if not handle:
            raise ConfigError("Could not allocate clipboard memory.")
        locked = kernel32.GlobalLock(handle)
        if not locked:
            raise ConfigError("Could not lock clipboard memory.")
        ctypes.memmove(locked, data, len(data))
        kernel32.GlobalUnlock(handle)
        if not user32.SetClipboardData(CF_HDROP, handle):
            raise ConfigError("Could not set file clipboard data.")
        handle = None
    finally:
        user32.CloseClipboard()


def put_text_on_clipboard(text: str) -> None:
    if os.name != "nt":
        raise ConfigError("Text clipboard paste is only implemented for Windows.")

    data = (text + "\0").encode("utf-16le")

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    CF_UNICODETEXT = 13
    GMEM_MOVEABLE = 0x0002
    GMEM_ZEROINIT = 0x0040

    user32.OpenClipboard.argtypes = [ctypes.c_void_p]
    user32.OpenClipboard.restype = ctypes.c_bool
    user32.EmptyClipboard.argtypes = []
    user32.EmptyClipboard.restype = ctypes.c_bool
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    user32.SetClipboardData.restype = ctypes.c_void_p
    user32.CloseClipboard.argtypes = []
    user32.CloseClipboard.restype = ctypes.c_bool

    kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.restype = ctypes.c_bool

    if not user32.OpenClipboard(None):
        raise ConfigError("Could not open Windows clipboard.")

    handle = None
    try:
        user32.EmptyClipboard()
        handle = kernel32.GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT, len(data))
        if not handle:
            raise ConfigError("Could not allocate clipboard memory.")
        locked = kernel32.GlobalLock(handle)
        if not locked:
            raise ConfigError("Could not lock clipboard memory.")
        ctypes.memmove(locked, data, len(data))
        kernel32.GlobalUnlock(handle)
        if not user32.SetClipboardData(CF_UNICODETEXT, handle):
            raise ConfigError("Could not set text clipboard data.")
        handle = None
    finally:
        user32.CloseClipboard()


def build_cf_hdrop_data(paths: list[str]) -> bytes:
    # DROPFILES with fWide=true, followed by a double-null-terminated UTF-16 path list.
    header_size = 20
    files = ("\0".join(paths) + "\0\0").encode("utf-16le")
    return (
        int(header_size).to_bytes(4, "little")
        + int(0).to_bytes(4, "little", signed=True)
        + int(0).to_bytes(4, "little", signed=True)
        + int(0).to_bytes(4, "little")
        + int(1).to_bytes(4, "little")
        + files
    )


def print_schedule(config: AppConfig) -> None:
    print(f"Group: {config.group_name or '(not set)'}")
    print(f"Address: {config.address or '(not set)'}")
    print(f"Normal folder: {config.normal_folder}")
    print(f"Friday folder: {config.friday_folder}")
    print("Slots:")
    for slot in config.slots:
        print(f"  - {slot.name}: {slot.send_time:%H:%M} / {slot.image_name} / label={slot.label}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Render scheduled check-in images and send them to a Viber Desktop group.")
    parser.add_argument("--config", default=str(CONFIG_PATH), help="Path to config.toml")

    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("list", help="Show configured schedule")

    render_parser = subparsers.add_parser("render", help="Render one image without sending")
    render_parser.add_argument("slot", help="Slot name or time, for example 5pm or 17:00")
    render_parser.add_argument("--date", help="Test with a specific date, YYYY-MM-DD")

    send_parser = subparsers.add_parser("send-now", help="Render and send one configured slot immediately")
    send_parser.add_argument("slot", help="Slot name or time, for example 5pm or 17:00")
    send_parser.add_argument("--dry-run", action="store_true", help="Render only and show what would be sent")
    send_parser.add_argument("--date", help="Test with a specific date, YYYY-MM-DD")

    run_parser = subparsers.add_parser("run", help="Run the scheduler loop")
    run_parser.add_argument("--dry-run", action="store_true", help="Render due images without sending to Viber")

    args = parser.parse_args(argv)

    try:
        config = load_config(Path(args.config).resolve())
        if args.command == "list":
            print_schedule(config)
        elif args.command == "render":
            slot = find_slot(config, args.slot)
            print(render_image(config, slot, parse_test_date(args.date) if args.date else None))
        elif args.command == "send-now":
            slot = find_slot(config, args.slot)
            send_slot(config, slot, dry_run=args.dry_run, mark=False, now=parse_test_date(args.date) if args.date else None)
        elif args.command == "run":
            run_scheduler(config, dry_run=args.dry_run)
    except KeyboardInterrupt:
        print("Stopped.")
        return 130
    except ConfigError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    return 0


def parse_test_date(value: str) -> datetime:
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise ConfigError(f"Invalid --date value, expected YYYY-MM-DD: {value}") from exc
    return datetime.combine(parsed, datetime.now().time())


if __name__ == "__main__":
    raise SystemExit(main())
